//-----------------------------------------------------------------------------
//   ____  ____
//  /   /\/   /
// /___/  \  /   Vendor: Xilinx
// \   \   \/    Version: 1.0
//  \   \        Filename: $RCSfile: c_model.c,v $
//  /   /        Date Last Modified: $Date: 2011/04/11 10:39:06 $
// /___/   /\    Date Created: 2009
// \   \  /  \
//  \___\/\___\
//
// Device  : All
// Library : example_v1_0
// Purpose : ROMs wrapper for testing bit accurate C model
//-----------------------------------------------------------------------------
//  (c) Copyright 2009 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES. 
//-------------------------------------------------------------------
// Description:
//
// This wrapper file uses the simulation info file sim.inf to create:
// Input test files
// Golden data results (by running the C model on the input files)
//
// Uses a portable random number generator rather than the C rand()
// function, to give the same results on all platforms.  This permits
// rerunning on any platform when debugging failing tests.
//-------------------------------------------------------------------

// Include files 

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#ifdef NT
  #include <direct.h>
#else
  #include <sys/stat.h>
#endif

#ifndef yuv_utils_h
#include "yuv_utils.h"
#endif

#ifndef  v_scaler_v8_1_bitacc_cmodel_h
#include "v_scaler_v8_1_bitacc_cmodel.h"
#endif

#ifndef  v_ycrcb2rgb_v4_0_bitacc_cmodel_h
#include "v_ycrcb2rgb_v4_0_bitacc_cmodel.h"
#endif

#include "xscaler_coefs.h"

// Clive's generics
#define NUM_GENERICS 18
#define NUM_TEST_ARGUMENTS 14
#define NUM_PHASE_OPTIONS 17
#define NUM_TAP_OPTIONS 11
#define TAP_OPTIONS  {2,3,4,5,6,7,8,9,10,11,12}
#define PHASE_OPTIONS {2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,32,64}
#define GENERATE_COEFFS
#define pi 3.14159265358979

// Resolution of default YUV file video_in_128x128.yuv
#define DEFAULT_YUV_MAX_SRC_H_RES 128
#define DEFAULT_YUV_MAX_SRC_V_RES 128

#define SPEC_MAX_TAPS 12
#define SPEC_MAX_PHASES 64
#define SPEC_MAX_COEF_SETS 16
#define SPEC_MAX_BANKS 4
#define MAX_TEST_CASES 16

#define SPEC_MAX_SET_SIZE   SPEC_MAX_BANKS*SPEC_MAX_PHASES*SPEC_MAX_TAPS


#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#pragma warning( disable : 4996 )

// Scaler setup:
struct  xilinx_ip_v_scaler_v8_1_generics     scaler_generics;
struct  xilinx_ip_v_scaler_v8_1_inputs       scaler_yuv422_8b_inputs;
struct  xilinx_ip_v_scaler_v8_1_inputs       scaler_yuv420_8b_inputs;
struct  xilinx_ip_v_scaler_v8_1_inputs       scaler_inputs;
struct  xilinx_ip_v_scaler_v8_1_outputs      scaler_yuv422_8b_outputs;
struct  xilinx_ip_v_scaler_v8_1_outputs      scaler_outputs;
struct  xilinx_ip_v_ycrcb2rgb_v4_0_generics     ycrcb2rgb_generics;
struct  xilinx_ip_v_ycrcb2rgb_v4_0_inputs       ycrcb2rgb_inputs;
struct  xilinx_ip_v_ycrcb2rgb_v4_0_outputs      ycrcb2rgb_outputs;
struct  yuv8_video_struct                       yuv8_video_in ;
struct  yuv8_video_struct                       yuv8_video_out ;
struct  yuv8_video_struct                       ycrcb444_video_in ;
struct  yuv8_video_struct                       ycrcb420_video_in;

FILE*       input_fid               = NULL;
FILE*       output_fid              = NULL;
FILE*       output_coe_fid          = NULL;
FILE*       stim_in_fid             = NULL;
FILE*       gold_out_fid            = NULL;
FILE*       user_coefs_fid          = NULL;
FILE*       report_fid              = NULL;
FILE*       cfgFile_fid             = NULL;
FILE*       VHDLCoefsFile_fid       = NULL;
FILE*       CFG_Verilog_fid         = NULL;
FILE*       miffid                  = NULL;

int   CreateCoeFile = 1;
int   GenerateCFGFile = 1;

int*  CoefMatrix;
int   ErrorCount = 0;
int   WarningCount = 0;
int   CfgFileFound = 0;
int   RepoDirFound = 0;
int   COEFileFound = 0;
int   GenericsFound = 0;
int   InputYUVFileFound = 0;
int   OutputYUVFileFound = 0;
char  Fname[512];
char  ReportFname[512];
char  TestDirName[512];
char  TestDirectory[512];
char  TestCfgDirectory[512];
char  StimDirectory[512];
char  ResultDirectory[512];
char  ExpectedDirectory[512];
char  VerilogDirectory[512];
char  TestNumDirectory[512];
char  TestRootDir[512];
char  NumStr[512];
int   EnableRoguePixel = 0;   // For use with Ramp only. Generates a random luma value at a single fixed location (0, 69), and
                              // another random chroma value at a different single fixed location (0, 37)
                              // Useful when generating ramp data for testing the MANR.

int print_help(void)
{
   printf("\nUsage: run_bitacc_cmodel -c <cfg file> -t <test name> -y <YUV File> -h <hsize> -v <vsize>\n");
   printf("     cfg file   :  Path/name of the scaler config (.cfg) file.\n");
   printf("     test name  :  Name of test specified in .cfg file.\n");
   printf("                   Use 'all' to generate all tests specified in .cfg file\n");
   printf("     YUV file   :  Path/name of Input YUV File.\n");
   printf("     hsize      :  Source YUV file Horizontal size.\n");
   printf("     vsize      :  Source YUV file Vertical size.\n\n");
   printf("     Example: run_bitacc_cmodel -c ./scaler.cfg -t test001 -v ./video_in.yuv\n");

   return(0);
}

int alloc_coefs_buff(struct coefs_struct* coefs, int max_taps, int max_phases)
{   
  int phase, tap, bank;

  for (bank = 0; bank < 4; bank++) {
    if ((coefs->coefficients[bank] = (int **) allocbuff16p(max_phases)) == 0) return(1);
    for (phase = 0; phase <max_phases; phase++) {
      if ((coefs->coefficients[bank][phase] = (int *) allocbuff16p(max_taps)) == 0) return(1);
    }
  }
  return(0);
}

void free_coefs_buff(struct coefs_struct* coefs, int max_taps, int max_phases)
{   
   int phase, tap, bank;

   for (bank = 0; bank < 4; bank++) {
      for (phase = 0; phase <max_phases; phase++)
         free(coefs->coefficients[bank][phase]); 
      free(coefs->coefficients[bank]); 
   }
}

int CoefValueLookup(int InSize, int OutSize, int NumTaps, int NumPhases)
{
   int   CoeffBinIndex;
   int   CoefSetOffset, CoeffValueOffset;
   int   i, j;
   int   NumLinesPerTapOption;
   int   NumValuesInTapOption[NUM_TAP_OPTIONS];
   int   PhaseOptions[] = PHASE_OPTIONS;
   int   TapOptions[] = TAP_OPTIONS;

   /* Find the index of the Coefficient Bin */
   if (OutSize > InSize) 
      CoeffBinIndex = 0;
   else
      CoeffBinIndex = (OutSize*16)/InSize;

   // Now the more tricky bit is to locate the set you need from the hugely long list of coefficients
   // defined in xscaler_coefs.c

   // First calculate the number of n-tap lines (in XScaler_Coefficients array) for each tap option.
   // - just sum all the values in PhaseOptions[].
   // - I'm sure there's a better way of doing this...
   NumLinesPerTapOption=0;
   for(i=0;i<NUM_PHASE_OPTIONS;i++)
      NumLinesPerTapOption+=PhaseOptions[i]; // This is the same for each tap option.

   // Next, calculate the number of values in each tap option.
   for(i=0;i<NUM_TAP_OPTIONS;i++)
      NumValuesInTapOption[i]=NumLinesPerTapOption*TapOptions[i];

   CoefSetOffset=0;
   for(i=0;i<NUM_TAP_OPTIONS;i++)
   {
      if (NumTaps == TapOptions[i])
      {
         for(j=0;j<NUM_PHASE_OPTIONS;j++)
         {
            if (NumPhases == PhaseOptions[j])
            {
               // The Coefficient offset in this array has now been calculated.
               return(CoefSetOffset);
            }
            else
               CoefSetOffset+=(PhaseOptions[j]*NumTaps);
         }
      }
      else // i is not the correct number of taps, so add NumValuesInTapOption to CoefSetOffset.
         CoefSetOffset+=NumValuesInTapOption[i];
   }
   return(0);

}

int matlab_flr(double x)
{
   if(x<0) 
      return (int)(x-(1-1E-23));
   else
      return (int)(x);
}

int matlab_rnd(double x)
{
   return matlab_flr(x+0.5);
}

int CalculateScaleFactor(int InSize, int OutSize)
{
   float scale_factor;
   scale_factor=(float)InSize/(float)OutSize;
   return(matlab_rnd(scale_factor*1048576.0)); //1048576=2^20
}

////sine generation
// This Sine generation algorithm implements Taylor series decomposition of the 
// Sine function according to http://en.wikipedia.org/wiki/Taylor_series#Approximation_and_convergence

float sine(float x)
{
    int n, fac=1;
    float px, taylor=0;
	float rng = ((x-pi)/pi);
	x = x - rng*pi;
	px = x;
    for (n=0;n<6;n++)
    {
        taylor +=  (px / fac);
        px *= -(x*x);
        fac *= (2*n+2)*(2*n+3);
    }
    return taylor;
}

float lanczos(float x, int a) 
{
  return((x<-a) ? 0 : ((x>a) ? 0 : ((x==0) ? 1.0 : ( a*sine(pi*x)*sine(pi*x/a)/(pi*pi*x*x)))));
}
// This coefficient generation algorithm implements the Lanczos coefficients: http://en.wikipedia.org/wiki/Lanczos_resampling
// For a particular scaling ratio, the coefficients can be pre-canned to memory
void get_lanczos_coeffs(float p, int *icoeffs, int NCOEFF)
{
  float s=0;
  float coeff[64];

  int i;
  for (i=0; i<NCOEFF; i++) s+=(coeff[i] = lanczos( i-(NCOEFF>>1)+p, (NCOEFF>>1)));    // To implement convolution using the 2D FIR kernel, coefficient order is reversed
  for (i=0; i<NCOEFF; i++) icoeffs[i]=(int) (0.5+coeff[i]*16384/s);              // Normalize coefficients, so sum()=1 for all phases.
}


void CreateCoefsMatrix (
                  struct xilinx_ip_v_scaler_v8_1_generics  generics,
                  struct xilinx_ip_v_scaler_v8_1_inputs    inputs,
                  struct xilinx_ip_v_scaler_v8_1_outputs*  outputs,
				  int ForceUnityCoefs)
{
   int i, j, h, phase, tap;
   int *coef_matrix;
   int coef_bin, TapIndex, num_taps, num_phases;
   int y_aperture_h_size, y_aperture_v_size;
   int hsf, vsf;
   float h_scale_factor, v_scale_factor, scale_factor;
   int CoeffPhaseOffset;
   int* current_phase_ptr;
   int* current_taps_ptr;
   double dy;

   y_aperture_h_size = inputs.aperture_end_pixel-inputs.aperture_start_pixel+1;
   y_aperture_v_size = inputs.aperture_end_line-inputs.aperture_start_line+1;
   hsf=CalculateScaleFactor(y_aperture_h_size, outputs->video_out.cols);
   vsf=CalculateScaleFactor(y_aperture_v_size, outputs->video_out.rows);
   // Quantize x_scale_factors
   h_scale_factor=((float)hsf)/1048576.0;
   v_scale_factor=((float)vsf)/1048576.0;
   for (h=0;h<4;h++)
   {
      if (h<2) 
      { // HY, HC
         num_phases     = inputs.num_h_phases;
         num_taps       = generics.num_h_taps;
         scale_factor   = h_scale_factor; 
         CoeffPhaseOffset=CoefValueLookup(y_aperture_h_size, outputs->video_out.cols, generics.num_h_taps, inputs.num_h_phases);
      }
      else 
      { // VY, VC
         num_phases     = inputs.num_v_phases;
         num_taps       = generics.num_v_taps;
         scale_factor   = v_scale_factor;    
         CoeffPhaseOffset=CoefValueLookup(y_aperture_v_size, outputs->video_out.rows, generics.num_v_taps, inputs.num_v_phases);
      }

      if (generics.UserCoefsEnabled == 0)
      {
         // Select Coefficient Bin
         if (ForceUnityCoefs == 1)
            coef_bin = 18;
         else if (scale_factor>=1.0) // downscaling
            coef_bin = (int)((1.0/scale_factor)*16)+1;
         else
            coef_bin = 1;

			#ifdef GENERATE_COEFFS
			  for (phase=0; phase<num_phases; phase++) {
				dy=((double) phase)/num_phases;    
				current_phase_ptr = inputs.SingleFrameCoefs.coefficients[h][phase];
				get_lanczos_coeffs(dy,current_phase_ptr, num_taps);
				for (tap=0;tap<num_taps;tap++)
					fprintf(report_fid,"% 6d", inputs.SingleFrameCoefs.coefficients[h][phase][tap]);
				fprintf(report_fid,"\n");
			  }
			#else
         // Use default coefficients that are compiled from xscaler_coefs.h
         for (i=0;i<num_phases;i++)
         {
            for (j=0;j<num_taps;j++)
            {
               TapIndex = CoeffPhaseOffset+(i*num_taps)+j;
               inputs.SingleFrameCoefs.coefficients[h][i][j]=(int)XScaler_Coefficients[coef_bin-1][TapIndex];
            }
         }
#endif
      }
      else
      {
         // Use coefficients defined in user-specified .coe file
         for (i=0;i<num_phases;i++)
         {
            for (j=0;j<num_taps;j++)
            {
               TapIndex = j;
               inputs.SingleFrameCoefs.coefficients[h][i][j]=generics.init_coefs.coefficients[h][i][TapIndex];
            }
         }
      }
   }  
}


int BitExtend( struct video_struct* video_in , int EnableRamp, struct video_struct* video_out )
{
  int frame, row, col, crows, ccols;
  int ExtensionValue;
  int bitdiff;
  get_chroma_size( (struct yuv_video_struct*) video_in , &crows, &ccols);


   // Verify that the video structs and frame buffers exist:
  if (video_in== NULL) 
  {    
     fprintf(report_fid, "Error: BitExtend: Input video struct not defined!\n"); 
     return(100); 
  }
  if (video_in->data[0] == NULL) 
  { 
     fprintf(report_fid, "Error: BitExtend: Input video buffer does not exist!\n"); 
     return(101); 
  }
  if (video_out == NULL) 
  {  
     fprintf(report_fid, "Error: BitExtend: Output video struct not defined!\n"); 
     return(102); 
  }
   if (video_out->data == NULL) 
   {
      // Here is the default copy constructor
      video_out->mode           = video_in->mode;
      video_out->frames         = video_in->frames;
      video_out->rows           = video_in->rows;
      video_out->cols           = video_in->cols;
      if (alloc_video_buff( video_out )>0) 
         return(1);  // Could not allocate frame buffer
      }
      else
      {
         if ( 
                  (video_out->rows != video_in->rows) 
               || (video_out->cols != video_in->cols) 
               || (video_out->frames != video_in->frames)
               ||
               (
                  (video_out->mode!= video_in->mode) && 
                  (
                     (video_out->mode!=FORMAT_MONO_M || video_in->mode!=FORMAT_MONO) &&
                     (video_out->mode!=FORMAT_C420_M || video_in->mode!=FORMAT_C420) &&
                     (video_out->mode!=FORMAT_C422_M || video_in->mode!=FORMAT_C422) &&
                     (video_out->mode!=FORMAT_RGB_M  || video_in->mode!=FORMAT_RGB) &&
                     (video_out->mode!=FORMAT_C444_M || video_in->mode!=FORMAT_C444) &&
                     (video_out->mode!=FORMAT_C444   || video_in->mode!=FORMAT_RGB) 
                  )
               )
            ) 
            {
               fprintf(report_fid, "Error: BitExtend; Output buffer allocated is not the same size as the input buffer!\n"); 
               return(105); 
            }
      }

   // Confirm that input is lower bitwidth than output
   if ((bitdiff = video_out->bits_per_component - video_in->bits_per_component)<0)
   {   
      fprintf(report_fid, "Error: BitExtend: For bit extension, input bitwidth must be smaller than output bitwidth.\n"); return(0x103);
   }

 
	for (frame = 0; frame < video_in->frames; frame++)  {
		for (row = 0; row < video_in->rows; row++)
			for (col = 0; col < video_in->cols; col++) 
			{
				// Assign ExtensionValue as a random number. 
				// Assign 0 if ramp is enabled, for clarity.
				if (EnableRamp == 0)
					ExtensionValue=rand() & ((2<<bitdiff)-1);
				else
					ExtensionValue=0;
			    video_out->data[0][frame][row][col] = ((video_in->data[0][frame][row][col])<<bitdiff) | ExtensionValue;     // Extend Luminance/R
			}

		for (row = 0; row < crows; row++)
			for (col = 0; col < ccols; col++) 
			{
				// Assign ExtensionValue as a random number. 
				// Assign 0 if ramp is enabled, for clarity.
				if (EnableRamp == 0)
				   ExtensionValue=rand() & ((2<<bitdiff)-1);
				else
					ExtensionValue=0;
				video_out->data[1][frame][row][col] = ((video_in->data[1][frame][row][col])<<bitdiff) | ExtensionValue;     // Extend Chrominances/G&B
				video_out->data[2][frame][row][col] = ((video_in->data[2][frame][row][col])<<bitdiff) | ExtensionValue;
			}
  }
  return(0);
}

int OverrideWithRamp( struct yuv8_video_struct* yuv_in)
{
   int frame, row, col, crows, ccols;
   int chroma_val, luma_val;

   get_chroma_size( (struct yuv_video_struct*) yuv_in , &crows, &ccols);

   // Verify that the video structs and frame buffers exist:
   if (yuv_in== NULL) {    fprintf(report_fid, "Error: OverrideWithRamp: Input video struct not defined!\n"); return(0x100); }
   if (yuv_in->y== NULL) { fprintf(report_fid, "Error: OverrideWithRamp: Input video buffer does not exist!\n"); return(0x101); }
  

   for (frame = 0; frame < yuv_in->frames; frame++)  
   {
      chroma_val=0;
      for (row = 0; row < yuv_in->rows; row++)
      {
         luma_val=0;
         for (col = 0; col < yuv_in->cols; col++) 
         {
            if ((EnableRoguePixel == 1) && (row == 0) && (col == 69))
               luma_val = rand() & 0xff;
            else
			      luma_val = row & 0xff;

			   yuv_in->y[frame][row][col] = luma_val;
		   }
      }
      for (row = 0; row < crows; row++)
      {
         for (col = 0; col < ccols; col++) 
         {
            if ((EnableRoguePixel == 1) && (row == 0) && (col == 37))
               chroma_val = rand() & 0xff;
            else
               chroma_val = row & 0xff;

            yuv_in->u[frame][row][col] = chroma_val; 
            yuv_in->v[frame][row][col] = chroma_val;
         }
      }
   }
   return(0);
}
		
int OverrideWithRandom( struct yuv8_video_struct* yuv_in)
{
   int frame, row, col, crows, ccols;
   get_chroma_size( (struct yuv_video_struct*) yuv_in , &crows, &ccols);

   // Verify that the video structs and frame buffers exist:
   if (yuv_in== NULL) {    fprintf(report_fid, "Error: OverrideWithRandom: Input video struct not defined!\n"); return(0x100); }
   if (yuv_in->y== NULL) { fprintf(report_fid, "Error: OverrideWithRandom: Input video buffer does not exist!\n"); return(0x101); }
  

   for (frame = 0; frame < yuv_in->frames; frame++)  
   {
      for (row = 0; row < yuv_in->rows; row++)
      {
         for (col = 0; col < yuv_in->cols; col++) 
            yuv_in->y[frame][row][col] = rand() & 0xff;
      }
      for (row = 0; row < crows; row++)
      {
         for (col = 0; col < ccols; col++) 
         {
            yuv_in->u[frame][row][col] = rand() & 0xff;
            yuv_in->v[frame][row][col] = rand() & 0xff;
         }	
      }
   }
   return(0);
}


void WriteVideoTxtFile_CW(FILE* fid, struct video_struct* video_in, int Frame, int NumFrames) 
{
   int row, col;
   int Comp1Val, Comp2Val, Comp3Val;
   int FullVal;

   if (Frame == 0)
   {
      fprintf(fid, "Mode: %d\n", video_in->mode);
      fprintf(fid, "Frames: %d\n", NumFrames);
      fprintf(fid, "Field_sequence: %d\n", 0);
      fprintf(fid, "Rows: %d\n", video_in->rows);
      fprintf(fid, "Cols: %d\n", video_in->cols);
      fprintf(fid, "Bits_per_component: %d\n", video_in->bits_per_component);
   }

   for (row = 0; row < video_in->rows; row++)
   {
      for (col = 0; col < video_in->cols; col++)        
      {
         Comp1Val     = video_in->data[0][0][row][col];
         // Determine, pixel by pixel, what the component values are.
         switch (video_in->mode) 
         {
            case FORMAT_C444: 
            case FORMAT_RGB: 
               Comp2Val     = video_in->data[1][0][row][col];
               Comp3Val     = video_in->data[2][0][row][col];
               FullVal = (Comp3Val<<16)|(Comp2Val<<8)|Comp1Val;
               fprintf(fid, "%8d %8d %8d\n", Comp1Val, Comp2Val, Comp3Val);
               break;
            case FORMAT_C422: 
               Comp2Val     = video_in->data[1][0][row][col>>1];
               Comp3Val     = video_in->data[2][0][row][col>>1];
               if ((col&1) == 1)
                  fprintf(fid, "%8d %8d\n", Comp1Val, Comp2Val);
               else
                  fprintf(fid, "%8d %8d\n", Comp1Val, Comp3Val);
               break;
            case FORMAT_C420: 
               if ((row&1)==1)
               {
                  // For odd lines, copy chroma from previous line.
                  Comp2Val     = video_in->data[1][0][row>>1][col>>1]; 
                  Comp3Val     = video_in->data[2][0][row>>1][col>>1];
               }
               else
               {
                  Comp2Val     = video_in->data[1][0][row>>1][col>>1];
                  Comp3Val     = video_in->data[2][0][row>>1][col>>1];
               }
               if ((col&1) == 1)
                  fprintf(fid, "%8d %8d\n", Comp1Val, Comp2Val);
               else
                  fprintf(fid, "%8d %8d\n", Comp1Val, Comp3Val);
               break;
            default : 
               Comp2Val     = 0; // Monochrome
               Comp3Val     = 0; // Monochrome
         }
      }
   }
}


// **************************************************************************************
// This section makes the function calls to the c-model kernel.
// **************************************************************************************
int ExecuteScalerModel
(
   FILE* infid, 
   FILE* outfid, 
   int frames, int EnableYUVOutputGeneration, int EnableRamp, int EnableRandom
)
{
   int frame;
   int ret_val = 2;     // Corresponds to memory allocation error

   /////////////////////////////////////////////////////////////////////
   //  Execute Scaler Model
   for (frame = 0; frame<frames; frame++)
   {
      fprintf(report_fid, "   Processing frame %03d out of %d\n", frame, frames);
      printf("   Processing frame %03d out of %d\n", frame, frames);

      // Read 1 frame from YUV file into yuv8 structure
      read_yuv8(infid, &yuv8_video_in);

      if (EnableRamp == 1)
      {
         fprintf(report_fid, "   Overriding video data with Ramp data...\n");
         OverrideWithRamp(&yuv8_video_in);
      }
      else if (EnableRandom == 1)
      {
         fprintf(report_fid, "   Overriding video data with Random data...\n");
         OverrideWithRandom(&yuv8_video_in);
      }


      // Copy frame from yuv8 structure into generic video structure.
      // This is needed also by the YUV output generation. Hence it is not in the switch below.
      copy_yuv8_to_video(&yuv8_video_in, &(scaler_yuv422_8b_inputs.video_in));

       /////////////////////////////////////////////////////////////////
      // Scale YUV 4:2:2 video stream
      // If not generating stimulus text files, then don't bother 
      // running the scaler kernel for anything other than 4:2:2.
      /////////////////////////////////////////////////////////////////
      // Copy frame from yuv8 structure into generic video structures

      switch(scaler_inputs.video_in.mode)
      {
         case FORMAT_C422:
            // Bit-extend if necessary
            if (ret_val = BitExtend(&(scaler_yuv422_8b_inputs.video_in), EnableRamp, &(scaler_inputs.video_in))!= 0)
            {
               fprintf(report_fid, "BitExtend Error: %d\n", ret_val);
               return(ret_val);
            }
            // Write .txt input stimulus file for simulation and verification purposes.
            WriteVideoTxtFile_CW(stim_in_fid, &scaler_inputs.video_in, frame, frames);
            break;
         case FORMAT_RGB:
         case FORMAT_C444:
            //  Convert 4:2:2 YUV to 4:4:4 YUV for color-space conversion.
            yuv8_422to444(&yuv8_video_in, &ycrcb444_video_in);
            // Copy frame from yuv8 structure into generic video structure
            copy_yuv8_to_video(&ycrcb444_video_in, &(ycrcb2rgb_inputs.video_in));
            //  Execute YCrCb to RGB model: 
            xilinx_ip_v_ycrcb2rgb_v4_0_bitacc_simulate( &ycrcb2rgb_generics, &ycrcb2rgb_inputs, &ycrcb2rgb_outputs);
            // Bit-extend if necessary
            if (ret_val = BitExtend(&ycrcb2rgb_outputs.video_out, EnableRamp, &(scaler_inputs.video_in))!= 0)
            {
               fprintf(report_fid, "BitExtend Error: %d\n", ret_val);
               return(ret_val);
            }
            // Write .txt input stimulus file for simulation and verification purposes.
            WriteVideoTxtFile_CW(stim_in_fid, &scaler_inputs.video_in, frame, frames);
            break;
         case FORMAT_C420:
            //  Convert 4:2:2 YUV to 4:4:4 YUV for color-space conversion.
            yuv8_422to444(&yuv8_video_in, &ycrcb444_video_in);
            //  Convert 4:4:4 YUV to 4:2:0 YUV (Gabor didn't write a 4:2:2 to 4:2:0 converter!)
            yuv8_444to420(&ycrcb444_video_in, &ycrcb420_video_in);
            // Copy frame from yuv8 structure into generic video structure
            copy_yuv8_to_video(&ycrcb420_video_in, &(scaler_yuv420_8b_inputs.video_in));
            // Bit-extend if necessary
            if (ret_val = BitExtend(&(scaler_yuv420_8b_inputs.video_in), EnableRamp, &(scaler_inputs.video_in))!= 0)
            {
               fprintf(report_fid, "BitExtend Error: %d\n", ret_val);
               return(ret_val);
            }
            // Write .txt input stimulus file for simulation and verification purposes.
            WriteVideoTxtFile_CW(stim_in_fid, &scaler_inputs.video_in, frame, frames);
            break;
         default:
            printf("ERROR: Format not recognised\n");
            fprintf(report_fid, "ERROR: Format not recognised\n");
            return(300);
            break;
      }

      // ***********************************
      // Here is the function call.
      // ***********************************
      if ((ret_val = xilinx_ip_v_scaler_v8_1_bitacc_simulate( scaler_generics, scaler_inputs, &scaler_outputs))>0) 
      { 
         ErrorCount++; 
         return (ret_val);
      }
      
      // Write golden scaler output to .txt file.
      WriteVideoTxtFile_CW(gold_out_fid, &scaler_outputs.video_out, frame, frames);
      
      /////////////////////////////////////////////////////////////////
      // Generate output YUV file
      /////////////////////////////////////////////////////////////////
      // Copy frame from generic video structure into yuv8 structure 
      if (EnableYUVOutputGeneration==1)
      {
         // Scale the frame that is in scaler_yuv422_8b_inputs.
         if ((ret_val = xilinx_ip_v_scaler_v8_1_bitacc_simulate( scaler_generics, scaler_yuv422_8b_inputs, &scaler_yuv422_8b_outputs))>0) 
         {
            ErrorCount++; 
            return (ret_val);
         }
      }
      if (EnableYUVOutputGeneration==1)
      {
         // Copy scaled frame from generic video structure into yuv8 structure 
         copy_video_to_yuv8(&(scaler_yuv422_8b_outputs.video_out), &yuv8_video_out);
         // Write output frame into YUV file.
         write_yuv8(outfid, &yuv8_video_out);
	  }
   }


  fprintf(report_fid, "... done.\n");
  return(0);
}

void ParseCoeFile(FILE* user_coefs_fid, struct coefs_struct* coefs, char *line, int size, int max_taps, int max_phases)
{
   int h, i, j, k;
   char  FirstChar[256];
   char  TmpWord[256];
   int   x, tmp_coef;
  
   fprintf(report_fid, "Reading user coefficient file.\n");

   if ( fgets(line, size, user_coefs_fid) )
   {
      char *newline = strchr(line, '\n'); 
      if (newline)      
         *newline =  '\0'; /* overwrite the '\n' with a terminating null */      

      sscanf(line, "%s", FirstChar);
      if (x=strcmp(FirstChar,"memory_initialization_radix=10;")==0)
      {
         fprintf(report_fid, "Detected Radix 10. Note: Only Radix 10 accepted.\n");
      }
   }
   
   if ( fgets(line, size, user_coefs_fid) )
   {      
      sscanf(line, "%s", FirstChar);
      if (x=strcmp(FirstChar,"memory_initialization_vector=")==0)
      {
         fprintf(report_fid, "Detected vector declaration.\n");
      }
   }
      
   for (h=0;h<4;h++)   
   {
      for (i=0;i<max_phases;i++)
      {
         for (j=0;j<max_taps;j++)
         {
            fscanf(user_coefs_fid, "%d,\n", &tmp_coef);
            coefs->coefficients[h][i][j] = tmp_coef;
//            printf("%d\n", tmp_coef);
         }
      }
   }
}

void WriteCoefBank (FILE* txtfid, FILE* miffid, int* CoefMatrix, int max_taps, int max_phases, int GenerateStimulusFiles, int has_axi4_lite)
{
   int t_count, phase, i, j, Coeff;
   int OutVal, LSCoef, MSCoef, tapsdiv2;
   int result_vec[16];
   tapsdiv2=(max_taps+1)/2;

   if (GenerateStimulusFiles == 1)
   {
      for (phase = 0; phase < max_phases; phase++)
      {
         // First give the .txt file for simulation
         // Concatenate 2 coefficients together, and write the result out to the coefficient stimulus file.
         for (t_count = 0; t_count < tapsdiv2; t_count++)        
         {
            if (((t_count<<1)+1)>(max_taps-1))
               MSCoef = 0;
            else  
               MSCoef =CoefMatrix[(phase*max_taps)+(t_count<<1)+1];

            LSCoef = CoefMatrix[(phase*max_taps)+(t_count<<1)];
            if (LSCoef<0)
               LSCoef+=65536;

            OutVal=(MSCoef<<16) | LSCoef;
            if (has_axi4_lite == 1)
               fprintf(txtfid, "   R_CORE_COEF_DATA_IN_134 = 0x%08x\n", OutVal);

            if (MSCoef<0)
               MSCoef+=65536;
         }
      }


      // Write a mif file.
      for (phase = 0; phase < max_phases; phase++)
      {
         for (t_count = 0; t_count < max_taps; t_count++)        
         {
            Coeff =CoefMatrix[(phase*max_taps) + t_count];
            // Dec2Bin for Write MIF File!!!
            for (j=0; j<16;j++)
            {
               if (Coeff & 1)
                  result_vec[j] = 1;
               else
                  result_vec[j] = 0;
               Coeff = Coeff>>1;
            }
            for (j=0; j<16;j++)
               fprintf(miffid, "%d", result_vec[15-j]);
            fprintf(miffid, "\n");         
         }
      }
   }
}

void WriteCoefsFile(FILE* txtfid, FILE* miffid, int GenerateStimulusFiles, int* HYCoefsMatrix, int* HCCoefsMatrix, int* VYCoefsMatrix, int* VCCoefsMatrix, int num_h_taps, int num_v_taps, int max_phases, int num_h_phases, int num_v_phases, int Separate_YC_Coefs, int Separate_HV_Coefs, int ChromaFormat, int has_axi4_lite) 
{
   int phase, i, max_taps, tap;
   int* CoefMatrix;
   int NumBanks;
   
   max_taps = (num_h_taps>num_v_taps) ? num_h_taps : num_v_taps;
   CoefMatrix =(int *)calloc(max_taps*max_phases, sizeof(int));


   // For each of the 4 coefficient arrays, first transfer it to an array of a generic size defined by
   // max_phases and the maximum number of taps.

   // Regardless of anything, write the first coefficient bank
   for (phase = 0; phase < max_phases; phase++)
   {
      for (tap = 0; tap < max_taps; tap++)
      {
         if ((tap<num_h_taps) && (phase<num_h_phases))
            CoefMatrix[(phase*max_taps)+tap] = HYCoefsMatrix[(phase*num_h_taps)+tap];
         else
            CoefMatrix[(phase*max_taps)+tap] = 0;
      }
   }
   WriteCoefBank(txtfid, miffid, CoefMatrix, max_taps, max_phases, GenerateStimulusFiles, has_axi4_lite);

   // The second written bank must be a Chroma coefficient bank if:
   // 1. We are using YC422 or YC420 
   //    AND
   // 2. We have not specified shared coefficients between Y and C
   if ((Separate_YC_Coefs == 1) && (ChromaFormat != FORMAT_C444) && (ChromaFormat != FORMAT_RGB))
   {
      for (phase = 0; phase < max_phases; phase++)
      {
         for (tap = 0; tap < max_taps; tap++)
         {
            if ((tap<num_h_taps) && (phase<num_h_phases))
               CoefMatrix[(phase*max_taps)+tap] = HCCoefsMatrix[(phase*num_h_taps)+tap];
            else
               CoefMatrix[(phase*max_taps)+tap] = 0;
         }
      }
      WriteCoefBank(txtfid, miffid, CoefMatrix, max_taps, max_phases, GenerateStimulusFiles, has_axi4_lite);
   }
   // The next bank(s) will only be written if we have specified separate H and V coefficients.
   // Y AND C coeffs will be written if:
   // 1. Using YV422 or YC420 
   //    AND
   // 2. We have not specified shared coefficients between Y and C
   if (Separate_HV_Coefs == 1)
   {
      for (phase = 0; phase < max_phases; phase++)
      {
         for (tap = 0; tap < max_taps; tap++)
         {
            if ((tap<num_v_taps) && (phase<num_v_phases))
               CoefMatrix[(phase*max_taps)+tap] = VYCoefsMatrix[(phase*num_v_taps)+tap];
            else
               CoefMatrix[(phase*max_taps)+tap] = 0;
         }
      }
      WriteCoefBank(txtfid, miffid, CoefMatrix, max_taps, max_phases, GenerateStimulusFiles, has_axi4_lite);

      if ((Separate_YC_Coefs == 1) && (ChromaFormat != FORMAT_C444) && (ChromaFormat != FORMAT_RGB))
      {
         for (phase = 0; phase < max_phases; phase++)
         {
            for (tap = 0; tap < max_taps; tap++)
            {
               if ((tap<num_v_taps) && (phase<num_v_phases))
                  CoefMatrix[(phase*max_taps)+tap] = VCCoefsMatrix[(phase*num_v_taps)+tap];
               else
                  CoefMatrix[(phase*max_taps)+tap] = 0;
            }
         }
         WriteCoefBank(txtfid, miffid, CoefMatrix, max_taps, max_phases, GenerateStimulusFiles, has_axi4_lite);
      }
   }
}


void AppendCoeFileMatrix(
                           int SetNum,  
                           struct xilinx_ip_v_scaler_v8_1_generics  generics,
                           struct xilinx_ip_v_scaler_v8_1_inputs    inputs
) 
{
   int phase, i, max_taps, tap, bank;
   int num_banks;
   int bank_num = 0;
   int max_bank_size;
   int CoefMatrixIndex;

//   max_taps=max(num_h_taps, num_v_taps);
   max_taps = (generics.num_h_taps>generics.num_v_taps) ? generics.num_h_taps : generics.num_v_taps;
   max_bank_size=max_taps*generics.max_phases;
   
   num_banks = 4;
   if ((inputs.video_in.mode == FORMAT_C444) || (inputs.video_in.mode == FORMAT_RGB) || (generics.Separate_YC_Coefs == 0))
      num_banks = num_banks>>1;
   if (generics.Separate_HV_Coefs == 0)
      num_banks = num_banks>>1;

   // Regardless of anything, write the first coefficient bank
   // The coeff memory is configured as max_phases*max_taps in size.
   // If num_h_taps < max_taps, then the locations between num_h_taps and max_taps needs
   // to have a 0 written there in the coe file (padding).
   // Same is also true for the phases. This routine takes care of padding for both taps 
   // and phases.
   for (phase = 0; phase < generics.max_phases; phase++)
   {
      for (tap = 0; tap < max_taps; tap++)
      {
         CoefMatrixIndex = (SPEC_MAX_SET_SIZE*SetNum) + (phase*max_taps)+tap;
         if ((tap<generics.num_h_taps) && (phase<inputs.num_h_phases))
            CoefMatrix[CoefMatrixIndex] = inputs.SingleFrameCoefs.coefficients[0][phase][tap];
         else
            CoefMatrix[CoefMatrixIndex] = 0;
      }
   }

   // The second written bank must be a Chroma coefficient bank if:
   // 1. We are using YC422 or YC420 
   //    AND
   // 2. We have not specified shared coefficients between Y and C
   if ((generics.Separate_YC_Coefs == 1) && (inputs.video_in.mode != FORMAT_C444) && (inputs.video_in.mode != FORMAT_RGB))
   {
      bank_num++;
      for (phase = 0; phase < generics.max_phases; phase++)
      {
         for (tap = 0; tap < max_taps; tap++)
         {
            CoefMatrixIndex = (SPEC_MAX_SET_SIZE*SetNum) + (bank_num*max_bank_size) + (phase*max_taps)+tap;
            if ((tap<generics.num_h_taps) && (phase<inputs.num_h_phases))
               CoefMatrix[CoefMatrixIndex] = inputs.SingleFrameCoefs.coefficients[1][phase][tap];
            else
               CoefMatrix[CoefMatrixIndex] = 0;
         }
      }
   }
   // The next bank(s) will only be written if we have specified separate H and V coefficients.
   // Y AND C coeffs will be written if:
   // 1. Using YV422 or YC420 
   //    AND
   // 2. We have not specified shared coefficients between Y and C
   if (generics.Separate_HV_Coefs == 1)
   {
      bank_num++;
      for (phase = 0; phase < generics.max_phases; phase++)
      {
         for (tap = 0; tap < max_taps; tap++)
         {
            CoefMatrixIndex = (SPEC_MAX_SET_SIZE*SetNum) + (bank_num*max_bank_size) + (phase*max_taps)+tap;
            if ((tap<generics.num_v_taps) && (phase<inputs.num_v_phases))
               CoefMatrix[CoefMatrixIndex] = inputs.SingleFrameCoefs.coefficients[2][phase][tap];
            else
               CoefMatrix[CoefMatrixIndex] = 0;
         }
      }

      if ((generics.Separate_YC_Coefs == 1) && (inputs.video_in.mode != FORMAT_C444) && (inputs.video_in.mode != FORMAT_RGB))
      {
         bank_num++;
         for (phase = 0; phase < generics.max_phases; phase++)
         {
            for (tap = 0; tap < max_taps; tap++)
            {
               CoefMatrixIndex = (SPEC_MAX_SET_SIZE*SetNum) + (bank_num*max_bank_size) + (phase*max_taps)+tap;
               if ((tap<generics.num_v_taps) && (phase<inputs.num_v_phases))
                  CoefMatrix[CoefMatrixIndex] = inputs.SingleFrameCoefs.coefficients[3][phase][tap];
               else
                  CoefMatrix[CoefMatrixIndex] = 0;
            }
         }
      }
   }
}

void WriteCoeFile(FILE* coefid, 
                  struct xilinx_ip_v_scaler_v8_1_generics  generics,
                  struct xilinx_ip_v_scaler_v8_1_inputs    inputs,
                  int NumStreams)
{
   int set, phase, max_taps, tap, bank, num_banks, max_bank_size;
   int CoefMatrixIndex;
   max_taps = (generics.num_h_taps>generics.num_v_taps) ? generics.num_h_taps : generics.num_v_taps;
   max_bank_size=max_taps*generics.max_phases;
   
   num_banks = 4;
   if ((inputs.video_in.mode == FORMAT_C444) || (inputs.video_in.mode == FORMAT_RGB) || (generics.Separate_YC_Coefs == 0))
      num_banks = num_banks>>1;
   if (generics.Separate_HV_Coefs == 0)
      num_banks = num_banks>>1;

   if (NumStreams>generics.max_coef_sets)
   {
      if (CreateCoeFile == 1) 
      {

         fprintf (report_fid, "\nWarning: You have specified %d streams.\n", NumStreams);
         fprintf (report_fid, "         However, you have specified a maximum of only %d coefficient sets. \n", generics.max_coef_sets);
         fprintf (report_fid, "         Normally, each test will add one set of coefficients to the .coe file. \n");
         fprintf (report_fid, "         In this case, only sets from the first %d tests will be included.\n\n", generics.max_coef_sets);
         WarningCount++;
      }
   }

   for (set = 0; set < generics.max_coef_sets; set++)
   {
   // Now that we have a fully populated CoefMatrix, write it to a .coe file.
      for (bank = 0; bank < num_banks; bank++)
      {
         for (phase = 0; phase < generics.max_phases; phase++)
         {
            for (tap = 0; tap < max_taps; tap++)        
            {
               CoefMatrixIndex = (SPEC_MAX_SET_SIZE*set) + (bank*max_bank_size) + (phase*max_taps)+tap;
               if (set < NumStreams)
               {
                  if ((set==generics.max_coef_sets-1) && (tap==max_taps-1) && (phase==generics.max_phases-1) && (bank==num_banks-1))
                     fprintf(coefid, "%d;\n", CoefMatrix[CoefMatrixIndex]);
                  else
                     fprintf(coefid, "%d,\n", CoefMatrix[CoefMatrixIndex]);
               }
               else
               {
                  if ((set==generics.max_coef_sets-1) && (tap==max_taps-1) && (phase==generics.max_phases-1) && (bank==num_banks-1))
                     fprintf(coefid, "0;\n");
                  else
                     fprintf(coefid, "0,\n");
               }
            }
         }
      }
   }
}

int read_config_file(FILE* config_fid, char *line, int size, char* testname, char* YUVFile, int src_h_res, int src_v_res)
{
   int   ForceUnityCoefs;
   int   EnableRandom;
   char  text[256] = "";
   char  FirstChar[256];
   int   line_num=1;
   int   frames;
   int   ActiveTest;
   int   param_val, num_params;
   int   aperture_start_pixel, aperture_end_pixel, aperture_start_line, aperture_end_line;
   int   hsf, vsf;
   int   control = 3;
   int   output_h_size, output_v_size;
   int   has_axi4_lite = 1;
   int   num_h_taps = 0;
   int   num_v_taps = 0;
   int   Separate_YC_Coefs = 0;
   int   Separate_HV_Coefs = 0;
   int   fixed_mode_crop_start_pixel, fixed_mode_crop_end_pixel, fixed_mode_crop_start_line, fixed_mode_crop_end_line;
   int   fixed_mode_source_h_size, fixed_mode_source_v_size;
   int   fixed_mode_output_h_size, fixed_mode_output_v_size;
   int   fixed_mode_num_h_phases, fixed_mode_num_v_phases;
   int   fixed_mode_hsf, fixed_mode_vsf;
   int   max_phases = 0;
   int   num_h_phases = 0;
   int   num_v_phases = 0;
   int   max_coef_sets = 0;
   int   chroma_format = FORMAT_C422;
   int   tdata_width;
   int   bits_per_component;
//   int   src_h_res = DEFAULT_YUV_MAX_SRC_H_RES;
//   int   src_v_res = DEFAULT_YUV_MAX_SRC_V_RES;
   int   h_coeff_set = 0;
   int   v_coeff_set = 0;
   int   start_hpa_y = 0;
   int   start_hpa_c = 0;
   int   start_vpa_y = 0;
   int   start_vpa_c = 0;
   int   coef_set_wr_addr = 0;
   int   ParseYUVFile = 1;
   int   EnableYUVOutputGeneration = 1;
   int   y_aperture_v_size;
   int   y_aperture_h_size;
   int   x;
   int   CFGTestIsFocused;
   int   CFGTestIsBVT;
   int   h,i,j,k;
   int   EnableRamp;
   int   Source;
   int   UserCoefsEnabled;
   int   InitialOutputSizeFound = 0;
   int   OutputYUVFileHRes;
   int   OutputYUVFileVRes;
   int   ret_val;
   int   TestNumber=0;
   int   StreamNumber=0;
   int   BitsPerComponent;
   int   Mode;
   int   BankSize;
   int   *Y_coef_matrix_H_for_output, *Y_coef_matrix_V_for_output, *UV_coef_matrix_H_for_output, *UV_coef_matrix_V_for_output;
   int   IsBVT = 0;
   int   IsFocused = 0;
   char  user_coef_filename[512];
   char  Shorttestname[8];
   char  cfg_testname[512];
   char  COEFilename[512];
   char  YUVFilePath[512]; // Includes full path to YUV file including filename.

   if (strcmp(testname, "bvt") == 0)
      IsBVT = 1;
   else if (strcmp(testname, "focused") == 0)
      IsFocused = 1;
   else
   {
      IsBVT = 0;
      IsFocused = 0;
   }


   // Pre-allocate a large buffer for up to 16 sets of coefficients, each of the maximum size
   CoefMatrix =(int *)calloc(SPEC_MAX_TAPS*SPEC_MAX_PHASES*SPEC_MAX_COEF_SETS*SPEC_MAX_BANKS, sizeof(int));

   // Set up default YUV File name and path
   strcpy(YUVFilePath, YUVFile);
//   strcat(YUVFilePath, "/");
//   strcat(YUVFilePath, "video_in_128x128.yuv");

   while (!feof(config_fid))
   {
      FirstChar[0] = '#'; // Cheat!
      if ( fgets(line, size, config_fid) )   
      {      
         sscanf(line, "%s", &FirstChar[0]);
         if (FirstChar[0]!='#')
         {
            if (x=strcmp(FirstChar,"RepoDir")==0)
            {
               scaler_generics.UserCoefsEnabled = 0; // For each repo, default to internal coefficients.
               sscanf(line, "%s %s", FirstChar, &TestDirName);

               strcpy(ReportFname, TestDirName);
               strcat(ReportFname, "/cmodel_report.txt");
               if ( (report_fid = fopen(ReportFname, "w+t")) == NULL ) 
               {
                  printf( "\nError opening file: Could not open %s for writing.\n", ReportFname ); 
                  printf( "\nMake sure the specified RepoDir exists.\n\n", ReportFname ); 
                  ErrorCount++;
                  return(141); 
               }
               else
               {
                  RepoDirFound = 1;               
                  printf( "Opening file: %s for writing.\n", ReportFname); 
               }
               strcpy(Fname, TestDirName);
            }
            else if (x=strcmp(FirstChar,"ParseYUVFile")==0)
            {
               sscanf(line, " %s %d", FirstChar, &ParseYUVFile);

               if (ParseYUVFile == 1)
                  fprintf(report_fid, "YUV Input file generation ENABLED\n");
               else
                  fprintf(report_fid, "YUV Input file generation DISABLED\n");
            }
            
/*            else if (x=strcmp(FirstChar,"InputFile")==0)
            {
               // If "InputFile" is found in cfg file, then 
               //    1. replace path provided by -i option (datapath) with RepoDir
               //    2. replace default filename (video_in_128x128.yuv) with specified file to be found in Repodir.
               //    3. replace default resolution (128x128) with specified resolution.
               if (ParseYUVFile == 0)
               {
                  fprintf(report_fid, "\nInfo: Config File: Found input YUV file name, but YUV file parsing has been DISABLED!\n");
                  fprintf(report_fid, "      Setting source resolution as %dHx%dV, as specified anyway.\n", src_h_res, src_v_res);
                  fprintf(report_fid, "      (This is recommended practice).\n\n");
               }
               else
               {
                  fprintf(report_fid, "Found input YUV file name: %s\n", YUVFilePath);
                  fprintf(report_fid, "Input YUV resolution: %dHx%dV\n", src_h_res, src_v_res);
               }
               
               // Overwrite old with new.

               sscanf(line, " %s %s %d %d", FirstChar, &(scaler_yuv422_8b_inputs.filename[0]), &src_h_res, &src_v_res);
               strcpy(YUVFilePath, TestDirName);
               strcat(YUVFilePath, "/");
               strcat(YUVFilePath, scaler_yuv422_8b_inputs.filename);
            }
*/
            else if (x=strcmp(FirstChar,"EnableYUVOutputGeneration")==0)
            {
               sscanf(line, "%s %d", FirstChar, &EnableYUVOutputGeneration);
               if (EnableYUVOutputGeneration == 1)
               {
                  if (ParseYUVFile == 0)
                  {
                     fprintf(report_fid, "\nError: Config file: EnableYUVOutputGeneration has been set to 1. YUV Output file generation may \n");
                     fprintf(report_fid, "       only be enabled if YUV input file parsing has been enabled (set ParseYUVFile to 1 and.\n");
                     fprintf(report_fid, "       specify a YUV input file).\n\n");
                     ErrorCount++;
                  }
               }
               else
                  fprintf(report_fid, "YUV Output file generation DISABLED\n");
            }
            else if (x=strcmp(FirstChar,"OutputFile")==0)
            {
               sscanf(line, "%s %s", FirstChar, &(scaler_yuv422_8b_outputs.filename[0]));
               strcpy(Fname, TestDirName);
               strcat(Fname, "/");
               strcat(Fname, scaler_yuv422_8b_outputs.filename);
               if (EnableYUVOutputGeneration == 1)
               {
                  fprintf(report_fid, "Found output file name: %s\n", Fname);
                  if ( (output_fid = fopen(Fname, "w+b")) == NULL ) 
                  {
                     fprintf(report_fid,  "\nError opening file: Could not open output yuv file\n\n" ); 
                     fclose(report_fid); 
                     ErrorCount++;
                     return(8); 
                  }
                  else
                  {
                     OutputYUVFileFound = 1;
                  }
               }
               else
                  fprintf(report_fid, "Found output YUV file name but YUV file generation DISABLED.\n");
            }

            // Read core generics
            else if ((x=strcmp(FirstChar,"generics"))==0) //
            {
               // Switch ActiveTest OFF, before we establish that this is a test we want to proceed with.
               ActiveTest = 0;
               // Scan the generics from the input .cfg file
               GenericsFound = 1;
               fprintf(report_fid, "\nReading core generics from config file...\n" );
               num_params=sscanf(line, "%s %s %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d", 
                                    FirstChar,
                                    &cfg_testname[0],
                                    &has_axi4_lite,
                                    &num_h_taps,
                                    &num_v_taps,
                                    &max_phases,
                                    &max_coef_sets,
                                    &Separate_YC_Coefs,
                                    &Separate_HV_Coefs,
                                    &Mode,
                                    &BitsPerComponent,
                                    &fixed_mode_crop_start_pixel,
                                    &fixed_mode_crop_end_pixel,
                                    &fixed_mode_crop_start_line,
                                    &fixed_mode_crop_end_line,
                                    &fixed_mode_output_h_size,
                                    &fixed_mode_output_v_size,
                                    &fixed_mode_num_h_phases,
                                    &fixed_mode_num_v_phases
                                 );

               // Check the correct number of parameters were specified, and assign these values top the generics structure.
               if (num_params != 1+NUM_GENERICS)
               {
                  fprintf(report_fid, "\nError: Config file: Incorrect number of generics (%d) specified on line %d of configuration file.\n", num_params-1, line_num);
                  fprintf(report_fid, "       There should be %d generics.\n\n", NUM_GENERICS);
                  ErrorCount++;
                  return(23);
               }

               // Only create the specified test, in particular for IPV testing.
               // Allow for a 'all' option.
               // Allow for 'bvt' option

               strcpy (Shorttestname, "");
               for (k = 0; k<7;k++)
                  Shorttestname[k] = cfg_testname[k];
               Shorttestname[7] = 0;

               if (strcmp(Shorttestname, "focused") == 0)
                  CFGTestIsFocused = 1;
               else
                  CFGTestIsFocused = 0;

               if (strcmp(cfg_testname, "bvt") == 0)
                  CFGTestIsBVT = 1;
               else
                  CFGTestIsBVT = 0;

               if ((strcmp(testname, cfg_testname) != 0) && (strcmp(testname, "all") != 0) && (strcmp(testname, "full") != 0) && ((CFGTestIsFocused == 0) || (IsFocused == 0)))
                  fprintf(report_fid, "Found %s in .cfg file. Ignoring this test - does not match specified test-name (%s).\n", cfg_testname, testname );
               else
               {
                  fprintf(report_fid, "Found %s in config file. Processing...\n", cfg_testname);
                  ActiveTest = 1;
                  fixed_mode_hsf = CalculateScaleFactor(1 + fixed_mode_crop_end_pixel - fixed_mode_crop_start_pixel, fixed_mode_output_h_size);
                  fixed_mode_vsf = CalculateScaleFactor(1 + fixed_mode_crop_end_line - fixed_mode_crop_start_line, fixed_mode_output_v_size);

                  StreamNumber=0;
                  TestNumber++;
                  fprintf(report_fid, "\n\n********************************************************\n");
                  fprintf(report_fid, "Test: %s\n", cfg_testname);
                  fprintf(report_fid, "********************************************************\n");

                  if ((strcmp(testname, "all") == 0) || (strcmp(testname, "full") == 0))
                  {
                     // Make the dir where all test stimuli will be placed for ALL generics.
                     sprintf(TestDirectory, "%s/tests/", TestDirName);
                     #ifdef NT
                        mkdir(TestDirectory);
                     #else
                        mkdir(TestDirectory, 0755);
                     #endif
                     // Make the dir where all test stimuli will be placed for this set of generics.
                     // This dir will also contain the additional files coefs.vhd, coefs.coe, testcfg.v, testcfg.cfg
                     sprintf(TestNumDirectory, "%s/tests/%s", TestDirName, cfg_testname);
                     #ifdef NT
                        mkdir(TestNumDirectory);
                     #else
                        mkdir(TestNumDirectory, 0755);
                     #endif
                     strcpy(TestRootDir, TestNumDirectory);
                     strcpy(TestCfgDirectory, TestNumDirectory);
                     strcpy(StimDirectory, TestNumDirectory);
                     strcpy(ExpectedDirectory, TestNumDirectory);
                     strcpy(VerilogDirectory, TestNumDirectory);
                  }   

                  if ((strcmp(testname, cfg_testname) == 0) || (CFGTestIsBVT == 1) || (CFGTestIsFocused == 1))
                  {
                     // IPV test root directory.
                     strcpy(TestRootDir, TestDirName);

                     // Make the dir where config file test_config.cfg will be placed.
                     sprintf(TestCfgDirectory, "%s/testcfg", TestDirName);
                     #ifdef NT
                        mkdir(TestCfgDirectory);
                     #else
                        mkdir(TestCfgDirectory, 0755);
                     #endif
                     
                     // Make the dir where verilog config file test_config.v will be placed.
                     sprintf(VerilogDirectory, "%s/config", TestDirName);
                     #ifdef NT
                        mkdir(VerilogDirectory);
                     #else
                        mkdir(VerilogDirectory, 0755);
                     #endif
                     
                     // Make the dir where test stimuli will be placed.
                     sprintf(StimDirectory, "%s/stimuli", TestDirName);
                     #ifdef NT
                        mkdir(StimDirectory);
                     #else
                        mkdir(StimDirectory, 0755);
                     #endif
                     
                     // Make IPV result dir.
                     sprintf(ResultDirectory, "%s/result", TestDirName);
                     #ifdef NT
                        mkdir(ResultDirectory);
                     #else
                        mkdir(ResultDirectory, 0755);
                     #endif
                     
                     // Make the dir where golden vectors will be placed.
                     sprintf(ExpectedDirectory, "%s/expected", TestDirName);
                     #ifdef NT
                        mkdir(ExpectedDirectory);
                     #else
                        mkdir(ExpectedDirectory, 0755);
                     #endif
                     
                  }   


                   ///////////////////////////////////////////////////////////////////////
                  // Write a test#.cfg file in the standard cfg file format.
                  // open .cfg file for writing
                  strcpy (Fname, TestCfgDirectory);
                  strcat (Fname, "/test_config.cfg");
                  if ( (cfgFile_fid = fopen(Fname, "w+t")) == NULL ) 
                  {
                     fprintf(report_fid,  "\nError opening file: Could not open %s for writing.\n\n", Fname ); 
                     ErrorCount++;
                     return(129); 
                  }
                  else
                  {
                     fprintf(report_fid, "Opening file: %s for writing.\n", Fname);
                     fprintf(cfgFile_fid, "# File auto-generated by Video Scaler C-model (v_scaler_v8_1)\n\n");
                     fprintf(cfgFile_fid, "######################################################\n");
                     fprintf(cfgFile_fid, "## Config file for Test: %s\n", cfg_testname);
                     fprintf(cfgFile_fid, "######################################################\n\n");
                  }


                  strcpy(Fname, TestRootDir);
                  strcat(Fname, "/coefs.coe");
                  if (CreateCoeFile == 1)
                  {
                     if ( (output_coe_fid = fopen(Fname, "w+b")) == NULL ) 
                     {
                        fprintf(report_fid, "\nError opening file: Could not open output .coe file\n\n" ); 
                        fclose(report_fid); 
                        ErrorCount++;
                        return(50); 
                     }
                     else
                     {
                        fprintf(report_fid, "Opening coefficient file: %s for writing.\n", Fname); 
                        fprintf(output_coe_fid, "memory_initialization_radix=10;\n");
                        fprintf(output_coe_fid, "memory_initialization_vector=\n");
                        COEFileFound = 1;
                     }
                  }

                  scaler_generics.has_axi4_lite                      = has_axi4_lite;
                  scaler_generics.bits_per_component                 = BitsPerComponent;
                  scaler_generics.num_h_taps                         = num_h_taps;
                  scaler_generics.num_v_taps                         = num_v_taps;
                  if (has_axi4_lite == 1)
                     scaler_generics.max_phases                         = max_phases;
                  else
                     scaler_generics.max_phases                         = max(fixed_mode_num_h_phases, fixed_mode_num_v_phases);
                  scaler_generics.max_coef_sets                      = max_coef_sets;
                  scaler_generics.Separate_YC_Coefs                  = Separate_YC_Coefs;
                  scaler_generics.Separate_HV_Coefs                  = Separate_HV_Coefs;
                  scaler_generics.chroma_format                      = Mode;
                  scaler_generics.UserCoefsEnabled                   = 0;
                  scaler_generics.fixed_mode_crop_start_pixel        = fixed_mode_crop_start_pixel;
                  scaler_generics.fixed_mode_crop_end_pixel          = fixed_mode_crop_end_pixel;
                  scaler_generics.fixed_mode_crop_start_line         = fixed_mode_crop_start_line;
                  scaler_generics.fixed_mode_crop_end_line           = fixed_mode_crop_end_line;
                  scaler_generics.fixed_mode_source_h_size           = src_h_res;
                  scaler_generics.fixed_mode_source_v_size           = src_v_res;
                  scaler_generics.fixed_mode_output_h_size           = fixed_mode_output_h_size;
                  scaler_generics.fixed_mode_output_v_size           = fixed_mode_output_v_size;
                  scaler_generics.fixed_mode_num_h_phases            = fixed_mode_num_h_phases;
                  scaler_generics.fixed_mode_num_v_phases            = fixed_mode_num_v_phases;
                  scaler_generics.fixed_mode_hsf                     = fixed_mode_hsf;
                  scaler_generics.fixed_mode_vsf                     = fixed_mode_vsf;


                  // Support legacy assignments, until I rewrite this code.
                  BitsPerComponent              =  scaler_generics.bits_per_component ;
                  has_axi4_lite                 =  scaler_generics.has_axi4_lite;
                  num_h_taps                    =  scaler_generics.num_h_taps;
                  num_v_taps                    =  scaler_generics.num_v_taps;
                  max_phases                    =  scaler_generics.max_phases;
                  max_coef_sets                 =  scaler_generics.max_coef_sets;
                  Separate_YC_Coefs             =  scaler_generics.Separate_YC_Coefs;
                  Separate_HV_Coefs             =  scaler_generics.Separate_HV_Coefs;
                  Mode                          =  scaler_generics.chroma_format;
                  UserCoefsEnabled              =  0;
                  fixed_mode_crop_start_pixel   =  scaler_generics.fixed_mode_crop_start_pixel;
                  fixed_mode_crop_end_pixel     =  scaler_generics.fixed_mode_crop_end_pixel;
                  fixed_mode_crop_start_line    =  scaler_generics.fixed_mode_crop_start_line;
                  fixed_mode_crop_end_line      =  scaler_generics.fixed_mode_crop_end_line;
                  fixed_mode_source_h_size      =  scaler_generics.fixed_mode_source_h_size;
                  fixed_mode_source_v_size      =  scaler_generics.fixed_mode_source_v_size;
                  fixed_mode_output_h_size      =  scaler_generics.fixed_mode_output_h_size;
                  fixed_mode_output_v_size      =  scaler_generics.fixed_mode_output_v_size;
                  fixed_mode_num_h_phases       =  scaler_generics.fixed_mode_num_h_phases;
                  fixed_mode_num_v_phases       =  scaler_generics.fixed_mode_num_v_phases;
                  fixed_mode_hsf                =  scaler_generics.fixed_mode_hsf;
                  fixed_mode_vsf                =  scaler_generics.fixed_mode_vsf;

                  fprintf(cfgFile_fid, "[GENERAL]\n\n");
                  fprintf(cfgFile_fid, "##   Has_AXI4_Lite: %d\n", has_axi4_lite);
                  fprintf(cfgFile_fid, "##   Num H Taps: %d\n", num_h_taps);
                  fprintf(cfgFile_fid, "##   Num V Taps: %d\n", num_v_taps);
                  fprintf(cfgFile_fid, "##   Max Phases: %d\n", max_phases);
                  fprintf(cfgFile_fid, "##   Max Coef Sets: %d\n", max_coef_sets);
                  fprintf(cfgFile_fid, "##   Separate_YC_Coefs: %d\n", Separate_YC_Coefs);
                  fprintf(cfgFile_fid, "##   Separate_HV_Coefs: %d\n", Separate_HV_Coefs);
                  fprintf(cfgFile_fid, "##   Mode: %d\n", Mode);
                  fprintf(cfgFile_fid, "##   BitsPerComponent: %d\n", BitsPerComponent);
                  fprintf(cfgFile_fid, "##   fixed_mode_crop_start_pixel: %d\n", fixed_mode_crop_start_pixel);
                  fprintf(cfgFile_fid, "##   fixed_mode_crop_end_pixel: %d\n", fixed_mode_crop_end_pixel);
                  fprintf(cfgFile_fid, "##   fixed_mode_crop_start_line: %d\n", fixed_mode_crop_start_line);
                  fprintf(cfgFile_fid, "##   fixed_mode_crop_end_line: %d\n", fixed_mode_crop_end_line);
                  fprintf(cfgFile_fid, "##   fixed_mode_source_h_size: %d\n", fixed_mode_source_h_size);
                  fprintf(cfgFile_fid, "##   fixed_mode_source_v_size: %d\n", fixed_mode_source_v_size);
                  fprintf(cfgFile_fid, "##   fixed_mode_output_h_size: %d\n", fixed_mode_output_h_size);
                  fprintf(cfgFile_fid, "##   fixed_mode_output_v_size: %d\n", fixed_mode_output_v_size);
                  fprintf(cfgFile_fid, "##   fixed_mode_num_h_phases: %d\n", fixed_mode_num_h_phases);
                  fprintf(cfgFile_fid, "##   fixed_mode_num_v_phases: %d\n", fixed_mode_num_v_phases);
                  fprintf(cfgFile_fid, "##   fixed_mode_hsf: %d\n", fixed_mode_hsf);
                  fprintf(cfgFile_fid, "##   fixed_mode_vsf: %d\n\n", fixed_mode_vsf);
                  fprintf(cfgFile_fid, "[TRANSACTIONS]\n\n");

                  fprintf(report_fid, "      Has_AXI4_Lite: %d\n", has_axi4_lite);
                  fprintf(report_fid, "      Num H Taps: %d\n", num_h_taps);
                  fprintf(report_fid, "      Num V Taps: %d\n", num_v_taps);
                  fprintf(report_fid, "      Max Phases: %d\n", max_phases);
                  fprintf(report_fid, "      Max Coef Sets: %d\n", max_coef_sets);
                  fprintf(report_fid, "      Separate_YC_Coefs: %d\n", Separate_YC_Coefs);
                  fprintf(report_fid, "      Separate_HV_Coefs: %d\n", Separate_HV_Coefs);
                  fprintf(report_fid, "      Mode: %d\n", Mode);
                  fprintf(report_fid, "      BitsPerComponent: %d\n", BitsPerComponent);
                  fprintf(report_fid, "      fixed_mode_crop_start_pixel: %d\n", fixed_mode_crop_start_pixel);
                  fprintf(report_fid, "      fixed_mode_crop_end_pixel: %d\n", fixed_mode_crop_end_pixel);
                  fprintf(report_fid, "      fixed_mode_crop_start_line: %d\n", fixed_mode_crop_start_line);
                  fprintf(report_fid, "      fixed_mode_crop_end_line: %d\n", fixed_mode_crop_end_line);
                  fprintf(report_fid, "      fixed_mode_source_h_size: %d\n", fixed_mode_source_h_size);
                  fprintf(report_fid, "      fixed_mode_source_v_size: %d\n", fixed_mode_source_v_size);
                  fprintf(report_fid, "      fixed_mode_output_h_size: %d\n", fixed_mode_output_h_size);
                  fprintf(report_fid, "      fixed_mode_output_v_size: %d\n", fixed_mode_output_v_size);
                  fprintf(report_fid, "      fixed_mode_num_h_phases: %d\n", fixed_mode_num_h_phases);
                  fprintf(report_fid, "      fixed_mode_num_v_phases: %d\n", fixed_mode_num_v_phases);
                  fprintf(report_fid, "      fixed_mode_hsf: %d\n", fixed_mode_hsf);
                  fprintf(report_fid, "      fixed_mode_vsf: %d\n\n", fixed_mode_vsf);

                  ///////////////////////////////////////////////////////////////////////
                  // Write a testcfg.v file that can be used by the testbench.
                  // open cfg file for writing
                  strcpy (Fname, VerilogDirectory);
                  strcat (Fname, "/test_config.v");
                  if ( (CFG_Verilog_fid = fopen(Fname, "w+t")) == NULL ) 
                  {
                     fprintf(report_fid,  "\nError opening file: Could not open %s for writing.\n\n", Fname ); 
                     ErrorCount++;
                     return(131); 
                  }
                  else
                  {
                     switch(Mode)
                     {
                        case(FORMAT_RGB) :
                        case(FORMAT_C444) :
                           if (BitsPerComponent == 12)
                              tdata_width = 40;
                           else
                              tdata_width = 32;
                           break;
                        case(FORMAT_C422) :
                        case(FORMAT_C420) :
                           if (BitsPerComponent == 8)
                              tdata_width = 16;
                           else 
                              tdata_width = 24;
                           break;
                           break;
                        default:
                           tdata_width = 16;
                           break;
                     }

                     fprintf(CFG_Verilog_fid, "// File auto-generated by Video Scaler C-model (v_scaler_v8_1)\n\n");
                     fprintf(CFG_Verilog_fid, "// DEFINES FOR TB COMPONENT\n");
                     fprintf(CFG_Verilog_fid, "`define C_DUT_LATENCY                0\n");
                     fprintf(CFG_Verilog_fid, "`define C_AXI4LITE_DWIDTH            32\n");
                     fprintf(CFG_Verilog_fid, "`define C_AXI4LITE_AWIDTH            32\n");
                     fprintf(CFG_Verilog_fid, "`define C_S_AXIS_VIDEO_TDATA_WIDTH   %d\n", tdata_width);
                     fprintf(CFG_Verilog_fid, "`define C_M_AXIS_VIDEO_TDATA_WIDTH   %d\n", tdata_width);
                     fprintf(CFG_Verilog_fid, "`define C_S_AXIS_VIDEO_DATA_WIDTH    %d\n", BitsPerComponent);
                     fprintf(CFG_Verilog_fid, "`define C_M_AXIS_VIDEO_DATA_WIDTH    %d\n", BitsPerComponent);
                     fprintf(CFG_Verilog_fid, "`define C_S_AXI_ADDR_WIDTH           9\n");
                     fprintf(CFG_Verilog_fid, "`define C_S_AXI_DATA_WIDTH           32\n");
                     fprintf(CFG_Verilog_fid, "`define C_S_AXI_CLK_FREQ_HZ          100000000\n\n");

                     fprintf(CFG_Verilog_fid, "`define C_HAS_AXI4_LITE              %d\n", has_axi4_lite);
                     fprintf(CFG_Verilog_fid, "`define C_MAX_ACTIVE_COLS            %d\n", 4096);
                     fprintf(CFG_Verilog_fid, "`define C_AUTO_HW_CONFIG             %d\n", 0);
                     fprintf(CFG_Verilog_fid, "`define C_CHROMA_FORMAT              %d\n", Mode);
                     switch(Mode)
                     {
                        case(FORMAT_RGB) :
                        case(FORMAT_C444) :
                           fprintf(CFG_Verilog_fid, "`define C_MANUAL_HWC_VAL             7\n");
                           fprintf(CFG_Verilog_fid, "`define C_NUM_CHANNELS               3\n");
                           break;
                        case(FORMAT_C422) :
                           fprintf(CFG_Verilog_fid, "`define C_MANUAL_HWC_VAL             4\n");
                           fprintf(CFG_Verilog_fid, "`define C_NUM_CHANNELS               2\n");
                           break;
                        case(FORMAT_C420) :
                           fprintf(CFG_Verilog_fid, "`define C_MANUAL_HWC_VAL             3\n");
                           fprintf(CFG_Verilog_fid, "`define C_NUM_CHANNELS               2\n");
                           break;
                        default:
                           fprintf(CFG_Verilog_fid, "`define C_MANUAL_HWC_VAL             4\n");
                           fprintf(CFG_Verilog_fid, "`define C_NUM_CHANNELS               2\n");
                           break;
                     }

                     fprintf(CFG_Verilog_fid, "`define C_MAX_COEF_SETS              %d\n", max_coef_sets);
                     fprintf(CFG_Verilog_fid, "`define C_MAX_LINES_IN_PER_FRAME     %d\n", 4096);
                     fprintf(CFG_Verilog_fid, "`define C_MAX_LINES_OUT_PER_FRAME    %d\n", 4096);
                     fprintf(CFG_Verilog_fid, "`define C_MAX_PHASES                 %d\n", max_phases);
                     fprintf(CFG_Verilog_fid, "`define C_MAX_SAMPLES_IN_PER_LINE    %d\n", 4096);
                     fprintf(CFG_Verilog_fid, "`define C_MAX_SAMPLES_OUT_PER_LINE   %d\n", 4096);
                     fprintf(CFG_Verilog_fid, "`define C_NUM_H_TAPS                 %d\n", num_h_taps);
                     fprintf(CFG_Verilog_fid, "`define C_NUM_V_TAPS                 %d\n", num_v_taps);
                     fprintf(CFG_Verilog_fid, "`define C_READABLE_COEFS             %d\n", 1);
                     fprintf(CFG_Verilog_fid, "`define C_SEPARATE_YC_COEFS          %d\n", Separate_YC_Coefs);
                     fprintf(CFG_Verilog_fid, "`define C_SEPARATE_HV_COEFS          %d\n", Separate_HV_Coefs);
                     fprintf(CFG_Verilog_fid, "`define C_TARGET_MAX_FRAME_RATE      %d\n", 60);
                     fprintf(CFG_Verilog_fid, "`define C_TGT_CORE_CLK_FREQ          %d\n\n", 150);
      
                     fprintf(CFG_Verilog_fid, "// DEFINES FOR TOP LEVEL TB\n");
                     fprintf(CFG_Verilog_fid, "`define C_CLOCK_PERIOD               10\n");
                     fprintf(CFG_Verilog_fid, "`define C_RAND_SEED                  0\n");
                     fprintf(CFG_Verilog_fid, "`define C_TESTNAME                   \"%s\"\n\n", cfg_testname);

                     fprintf(CFG_Verilog_fid, "// DEFINES FOR FIXED MODE GENERICS\n");
                     fprintf(CFG_Verilog_fid, "`define C_APERTURE_START_PIXEL       %d\n", fixed_mode_crop_start_pixel);
                     fprintf(CFG_Verilog_fid, "`define C_APERTURE_END_PIXEL         %d\n", fixed_mode_crop_end_pixel);
                     fprintf(CFG_Verilog_fid, "`define C_APERTURE_START_LINE        %d\n", fixed_mode_crop_start_line);
                     fprintf(CFG_Verilog_fid, "`define C_APERTURE_END_LINE          %d\n", fixed_mode_crop_end_line);
                     fprintf(CFG_Verilog_fid, "`define C_SOURCE_H_SIZE              %d\n", fixed_mode_source_h_size);
                     fprintf(CFG_Verilog_fid, "`define C_SOURCE_V_SIZE              %d\n", fixed_mode_source_v_size);
                     fprintf(CFG_Verilog_fid, "`define C_OUTPUT_H_SIZE              %d\n", fixed_mode_output_h_size);
                     fprintf(CFG_Verilog_fid, "`define C_OUTPUT_V_SIZE              %d\n", fixed_mode_output_v_size);
                     fprintf(CFG_Verilog_fid, "`define C_NUM_H_PHASES               %d\n", fixed_mode_num_h_phases);
                     fprintf(CFG_Verilog_fid, "`define C_NUM_V_PHASES               %d\n", fixed_mode_num_v_phases);
                     fprintf(CFG_Verilog_fid, "`define C_HSF                        %d\n", fixed_mode_hsf);
                     fprintf(CFG_Verilog_fid, "`define C_VSF                        %d\n", fixed_mode_vsf);
                  }

               
                  strcpy (Fname, TestRootDir);
                  strcat (Fname, "/coefs.mif");

                  if ( (miffid = fopen(Fname, "w+t")) == NULL ) 
                  {
                     fprintf(report_fid,  "\nError opening file: Could not open %s for writing.\n\n", Fname ); 
                     ErrorCount++;
                     return(132); 
                  }
                  else 
                  {
                     fprintf(report_fid,  "Opened mif file %s for writing.\n\n", Fname ); 
                  }

                  // Design rules check
                  if (Separate_HV_Coefs == 0)
                  {
                     if (num_h_taps != num_v_taps)
                     {
                        fprintf(report_fid, "Error: num_v_taps must equal num_h_taps when Separate_HV_Coefs=0\n");
                        ErrorCount++;
                     }
                     fprintf(report_fid, "\nWARNING: You have set Separate_HV_Coefs to 0.\n");
                     fprintf(report_fid, "         H and V operations will use the same coefficients.\n");
                     fprintf(report_fid, "         Coefficients will be calculated according to the HORIZONTAL \n");
                     fprintf(report_fid, "         aperture size and \n");
                     fprintf(report_fid, "         HORIZONTAL output size. Vertical sizes will be ignored.\n\n");
                     WarningCount++;
                  }
                  if ((num_h_taps > SPEC_MAX_TAPS) || (num_v_taps > SPEC_MAX_TAPS))
                  {
                     fprintf(report_fid, "Error: num taps exceeds maximum of %d\n", SPEC_MAX_TAPS);
                     ErrorCount++;
                  }
                  if (max_phases > SPEC_MAX_PHASES)
                  {
                     fprintf(report_fid, "Error: max_phases (%d) exceeds maximum of %d\n", max_phases, SPEC_MAX_PHASES);
                     ErrorCount++;
                  }

                  if (max_coef_sets > SPEC_MAX_COEF_SETS)
                  {
                     fprintf(report_fid, "Error: max_coef_sets (%d) exceeds maximum of %d\n", max_coef_sets, SPEC_MAX_COEF_SETS);
                     ErrorCount++;
                  }
               }
            }

            // Final option, parse the dynamic parameters, avoiding commented lines.
            else if ((x=strcmp(FirstChar,"stream"))==0)//
            {


               if (ActiveTest == 1)
               {
                  StreamNumber++;
                  fprintf(report_fid, "\n/////////////////////////////////////\n");
                  fprintf(report_fid, "Generating test: %s, stream %d...\n", cfg_testname, StreamNumber);

                  // Open stimulus file for writing this stream.
                  sprintf(Fname, "%s/stim%d.txt", StimDirectory, StreamNumber);
                  if ( (stim_in_fid = fopen(Fname, "w+t")) == NULL ) 
                  {
                     fprintf(report_fid,  "\n   Error opening file: Could not open %s for writing.\n\n", Fname ); 
                     ErrorCount++;
                     return(101); 
                  }
                  else
                     fprintf(report_fid,  "   Opening file: %s for writing.\n", Fname); 
               
                  // Open golden output file for this testcase.

                  sprintf(Fname, "%s/gold%d.txt", ExpectedDirectory, StreamNumber);
                  if ( (gold_out_fid = fopen(Fname, "w+t")) == NULL ) 
                  {
                     fprintf(report_fid,  "\n   Error opening file: Could not open %s for writing.\n\n", Fname ); 
                     ErrorCount++;
                     return(102); 
                  }
                  else
                     fprintf(report_fid,  "   Opening file: %s for writing.\n", Fname); 

                  if (RepoDirFound == 0)
                  {
                     printf("\nError: No valid RepoDir found.\n\n");
                     ErrorCount++;
                     return(400);
                  }

                  if (GenericsFound == 0)
                  {
                     fprintf(report_fid, "\nError: No valid generics found in cfg file.\n\n");
                     ErrorCount++;
                     return(401);
                  }
                  if ((COEFileFound == 0) && (CreateCoeFile == 1))
                  {
                     fprintf(report_fid, "\nError: No valid .coe output file found.\n\n");
                     ErrorCount++;
                     return(402);
                  }
                  if ((EnableYUVOutputGeneration == 1) && (OutputYUVFileFound == 0))
                  {
                     fprintf(report_fid, "\nError: EnableYUVOutputGeneration = 1, but no valid .yuv output file found.\n\n");
                     ErrorCount++;
                     return(404);
                  }
                  if (ParseYUVFile == 1)
                  {
                     if ((input_fid = fopen(YUVFilePath, "rb" )) == NULL ) 
                     {
                        fprintf(report_fid,  "\nError opening file: Could not open input yuv file %s. \n\n", YUVFilePath ); 
                        ErrorCount++;
                        return(7); 
                     }
                     else
                     {
                        fprintf(report_fid, "   Opening input file: %s\n", YUVFilePath);
                        InputYUVFileFound = 1;
                     }
                  }
                  if ((ParseYUVFile == 1) && (InputYUVFileFound == 0))
                  {
                     fprintf(report_fid, "\nError: ParseYUVFile = 1, but no valid .yuv input file found.\n\n");
                     ErrorCount++;
                     return(403);
                  }

                  // Scan .cfg file for dynamic settings.
                  num_params=sscanf(line, "%s %d %d %d %d %d %d %d %d %d %d %d %d %s", 
                                       FirstChar,
                                       &frames,
                                       &aperture_start_pixel, 
                                       &aperture_end_pixel, 
                                       &aperture_start_line, 
                                       &aperture_end_line,
                                       &output_h_size,
                                       &output_v_size,
                                       &num_h_phases,
                                       &num_v_phases,
                                       &Source,
                                       &ForceUnityCoefs,
                                       &UserCoefsEnabled,
                                       &user_coef_filename[0]
                                    );
                                    
                  if (num_params != NUM_TEST_ARGUMENTS)
                  {
                     fprintf(report_fid, "Error: Config file: Incorrect number of arguments on line %d of configuration file.\n\n", line_num);
                     ErrorCount++;
                     return(230);
                  }
                  if ((num_h_phases > max_phases) && (has_axi4_lite == 1))
                  {
                     fprintf(report_fid, "Error: Config file: num_h_phases (%d) must be less than or equal to max_phases (%d).\n", num_h_phases, max_phases);
                     ErrorCount++;
                     return(231);
                  }
                  if ((num_v_phases > max_phases) && (has_axi4_lite == 1))
                  {
                     fprintf(report_fid, "Error: Config file: num_v_phases (%d) must be less than or equal to max_phases (%d).\n", num_v_phases, max_phases);
                     ErrorCount++;
                     return(232);
                  }
                  switch (Source)
                  {
                     case 0:
                        EnableRamp = 0;
                        EnableRandom = 0;
                        break;
                     case 1:
                        EnableRamp = 1;
                        EnableRandom = 0;
                        break;
                     case 2:
                        EnableRamp = 0;
                        EnableRandom = 1;
                        break;
                     default:
                        EnableRamp = 0;
                        EnableRandom = 0;
                        break;
                  }

                  if (InitialOutputSizeFound == 0)
                  {
                     InitialOutputSizeFound = 1;
                     OutputYUVFileHRes = output_h_size;
                     OutputYUVFileVRes = output_v_size;
                  }
                  else
                  {
                     if (EnableYUVOutputGeneration == 1)
                     {
                        if ((output_h_size != OutputYUVFileHRes) || (output_v_size != OutputYUVFileVRes))
                        {
                           fprintf(report_fid, "\nError: Config file: When generating an output YUV file, output resolutions of\n");
                           fprintf(report_fid, "       all tests must be the same.\n");
                           fprintf(report_fid, "       Stream# %d has a different output resolution to stream# 1\n", StreamNumber);
                           ErrorCount++;
                        }
                     }
                  }
                  if (ForceUnityCoefs == 1)
                     fprintf(report_fid, "   Overriding coefficients with unity coefficients in every phase...\n");

                  yuv8_video_in.rows                                    =  src_v_res;
                  yuv8_video_in.cols                                    =  src_h_res;
                  yuv8_video_in.frames                                  =  1;
                  yuv8_video_in.chroma_format                           =  chroma_format;
                  yuv8_video_in.bits_per_component                      =  8;

                  ycrcb420_video_in.rows                                =  src_v_res;
                  ycrcb420_video_in.cols                                =  src_h_res;
                  ycrcb420_video_in.frames                              =  1;
                  ycrcb420_video_in.chroma_format                       =  FORMAT_C420;
                  ycrcb420_video_in.bits_per_component                  =  8;

                  ycrcb444_video_in.rows                                =  src_v_res;
                  ycrcb444_video_in.cols                                =  src_h_res;
                  ycrcb444_video_in.frames                              =  1;
                  ycrcb444_video_in.chroma_format                       =  FORMAT_C444;
                  ycrcb444_video_in.bits_per_component                  =  8;

                  ycrcb2rgb_inputs.video_in.rows                        =  src_v_res;
                  ycrcb2rgb_inputs.video_in.cols                        =  src_h_res;
                  ycrcb2rgb_inputs.video_in.frames                      =  1;
                  ycrcb2rgb_inputs.video_in.mode                        =  FORMAT_C444;
                  ycrcb2rgb_inputs.video_in.bits_per_component          =  8;

                  ycrcb2rgb_outputs.video_out.rows                      =  src_v_res;
                  ycrcb2rgb_outputs.video_out.cols                      =  src_h_res;
                  ycrcb2rgb_outputs.video_out.frames                    =  1;
                  ycrcb2rgb_outputs.video_out.mode                      =  FORMAT_RGB;
                  ycrcb2rgb_outputs.video_out.bits_per_component        =  8;

                  scaler_inputs.video_in.rows                           =  src_v_res;
                  scaler_inputs.video_in.cols                           =  src_h_res;
                  scaler_inputs.video_in.frames                         =  1;
                  scaler_inputs.video_in.mode                           =  Mode; 
                  scaler_inputs.video_in.bits_per_component             =  BitsPerComponent;

                  scaler_yuv422_8b_inputs.video_in.frames               =  1;
                  scaler_yuv422_8b_inputs.video_in.mode                 =  FORMAT_C422; 
                  scaler_yuv422_8b_inputs.video_in.bits_per_component   =  8;
                  scaler_yuv422_8b_inputs.video_in.cols                 =  src_h_res;
                  scaler_yuv422_8b_inputs.video_in.rows                 =  src_v_res;

                  scaler_yuv422_8b_inputs.hsf                           =  CalculateScaleFactor(aperture_end_pixel-aperture_start_pixel+1, output_h_size);
                  scaler_yuv422_8b_inputs.vsf                           =  CalculateScaleFactor(aperture_end_line-aperture_start_line+1, output_v_size);

                  scaler_yuv420_8b_inputs.video_in.frames               =  1;
                  scaler_yuv420_8b_inputs.video_in.mode                 =  FORMAT_C420; 
                  scaler_yuv420_8b_inputs.video_in.bits_per_component   =  8;
                  scaler_yuv420_8b_inputs.video_in.rows                 =  src_v_res;
                  scaler_yuv420_8b_inputs.video_in.cols                 =  src_h_res;

                  scaler_outputs.video_out.frames                          =  1;
                  scaler_outputs.video_out.mode                            =  Mode;
                  scaler_outputs.video_out.bits_per_component              =  BitsPerComponent;

                  scaler_yuv422_8b_outputs.video_out.frames                =  1;
                  scaler_yuv422_8b_outputs.video_out.mode                  =  FORMAT_C422;
                  scaler_yuv422_8b_outputs.video_out.bits_per_component    =  8;

                  yuv8_video_out.frames                                 =  1;
                  yuv8_video_out.chroma_format                          =  chroma_format;
                  yuv8_video_out.bits_per_component                     =  8;

                  if (has_axi4_lite == 1)
                  {
                     scaler_inputs.aperture_start_pixel                    =  aperture_start_pixel;
                     scaler_inputs.aperture_end_pixel                      =  aperture_end_pixel;
                     scaler_inputs.aperture_start_line                     =  aperture_start_line;
                     scaler_inputs.aperture_end_line                       =  aperture_end_line;
                     scaler_inputs.num_h_phases                            =  num_h_phases;
                     scaler_inputs.num_v_phases                            =  num_v_phases;
                     scaler_inputs.hsf                                     =  CalculateScaleFactor(aperture_end_pixel-aperture_start_pixel+1, output_h_size);
                     scaler_inputs.vsf                                     =  CalculateScaleFactor(aperture_end_line-aperture_start_line+1, output_v_size);

                     scaler_yuv422_8b_outputs.video_out.cols               =  output_h_size;
                     scaler_yuv422_8b_outputs.video_out.rows               =  output_v_size;
                     scaler_outputs.video_out.cols                         =  output_h_size;
                     scaler_outputs.video_out.rows                         =  output_v_size;
                     yuv8_video_out.cols                                   =  output_h_size;
                     yuv8_video_out.rows                                   =  output_v_size;
                     scaler_yuv422_8b_inputs.aperture_start_pixel          =  aperture_start_pixel;
                     scaler_yuv422_8b_inputs.aperture_end_pixel            =  aperture_end_pixel;
                     scaler_yuv422_8b_inputs.aperture_start_line           =  aperture_start_line;
                     scaler_yuv422_8b_inputs.aperture_end_line             =  aperture_end_line;
                     scaler_yuv422_8b_inputs.num_h_phases                  =  num_h_phases;
                     scaler_yuv422_8b_inputs.num_v_phases                  =  num_v_phases;

                  }
                  else
                  {
                     scaler_inputs.aperture_start_pixel                    =  scaler_generics.fixed_mode_crop_start_pixel;
                     scaler_inputs.aperture_end_pixel                      =  scaler_generics.fixed_mode_crop_end_pixel;
                     scaler_inputs.aperture_start_line                     =  scaler_generics.fixed_mode_crop_start_line;
                     scaler_inputs.aperture_end_line                       =  scaler_generics.fixed_mode_crop_end_line;
                     scaler_inputs.num_h_phases                            =  scaler_generics.fixed_mode_num_h_phases;
                     scaler_inputs.num_v_phases                            =  scaler_generics.fixed_mode_num_v_phases;
                     scaler_inputs.hsf                                     =  scaler_generics.fixed_mode_hsf;
                     scaler_inputs.vsf                                     =  scaler_generics.fixed_mode_vsf;
                     scaler_yuv422_8b_outputs.video_out.cols               =  scaler_generics.fixed_mode_output_h_size;
                     scaler_yuv422_8b_outputs.video_out.rows               =  scaler_generics.fixed_mode_output_v_size;
                     scaler_outputs.video_out.cols                         =  scaler_generics.fixed_mode_output_h_size;
                     scaler_outputs.video_out.rows                         =  scaler_generics.fixed_mode_output_v_size;
                     yuv8_video_out.cols                                   =  scaler_generics.fixed_mode_output_h_size;
                     yuv8_video_out.rows                                   =  scaler_generics.fixed_mode_output_v_size;

                     scaler_yuv422_8b_outputs.video_out.cols               =  scaler_generics.fixed_mode_output_h_size;
                     scaler_yuv422_8b_outputs.video_out.rows               =  scaler_generics.fixed_mode_output_v_size;
                     scaler_outputs.video_out.cols                         =  scaler_generics.fixed_mode_output_h_size;
                     scaler_outputs.video_out.rows                         =  scaler_generics.fixed_mode_output_v_size;
                     yuv8_video_out.cols                                   =  scaler_generics.fixed_mode_output_h_size;
                     yuv8_video_out.rows                                   =  scaler_generics.fixed_mode_output_v_size;

                     // Re-assign to variables for legacy reasons.
                     aperture_start_pixel       =  scaler_generics.fixed_mode_crop_start_pixel;
                     aperture_end_pixel         =  scaler_generics.fixed_mode_crop_end_pixel;
                     aperture_start_line        =  scaler_generics.fixed_mode_crop_start_line;
                     aperture_end_line          =  scaler_generics.fixed_mode_crop_end_line;
                     num_h_phases               =  scaler_generics.fixed_mode_num_h_phases;
                     num_v_phases               =  scaler_generics.fixed_mode_num_v_phases;
                     output_h_size              =  scaler_generics.fixed_mode_output_h_size;
                     output_v_size              =  scaler_generics.fixed_mode_output_v_size;
                     scaler_yuv422_8b_inputs.aperture_start_pixel          =  scaler_generics.fixed_mode_crop_start_pixel;
                     scaler_yuv422_8b_inputs.aperture_end_pixel            =  scaler_generics.fixed_mode_crop_end_pixel;
                     scaler_yuv422_8b_inputs.aperture_start_line           =  scaler_generics.fixed_mode_crop_start_line;
                     scaler_yuv422_8b_inputs.aperture_end_line             =  scaler_generics.fixed_mode_crop_end_line;
                     scaler_yuv422_8b_inputs.num_h_phases                  =  scaler_generics.fixed_mode_num_h_phases;
                     scaler_yuv422_8b_inputs.num_v_phases                  =  scaler_generics.fixed_mode_num_v_phases;


                  }
                  if ((aperture_start_pixel < 0) ||
                      (aperture_start_pixel > src_h_res-1) ||
                      (aperture_end_pixel < 0) ||
                      (aperture_end_pixel > src_h_res-1) ||
                      (aperture_start_line < 0) ||
                      (aperture_start_line > src_v_res-1) ||
                      (aperture_end_line < 0) ||
                      (aperture_end_line > src_v_res-1))
                  {
                     fprintf(report_fid, "Error: Config file: Specified aperture is out of range.\n");

                     fprintf(report_fid, "       Source YUV file resolution: %dHx%dV.\n", src_h_res, src_v_res);
                     fprintf(report_fid, "       You specified H aperture: pixels %d to %d.\n", aperture_start_pixel, aperture_end_pixel);
                     fprintf(report_fid, "       You specified V aperture: lines  %d to %d.\n", aperture_start_line, aperture_end_line);
                     fprintf(report_fid, "       aperture_start_pixel, aperture_end_pixel must be in range 0 to %d inclusive.\n", src_h_res-1);
                     fprintf(report_fid, "       aperture_start_line, aperture_end_line must be in range 0 to %d inclusive.\n", src_v_res-1);
                     if (has_axi4_lite == 0)
                        fprintf(report_fid, "       (Note that the core is in Fixed Mode)\n");
                     ErrorCount++;
                  }

                  // Allocate dynamic buffers for video:
                  alloc_yuv8_frame_buff(&yuv8_video_in);
                  alloc_yuv8_frame_buff(&ycrcb444_video_in);
                  alloc_yuv8_frame_buff(&ycrcb420_video_in);
                  alloc_video_buff(&scaler_yuv422_8b_inputs.video_in);
                  
                  alloc_video_buff(&scaler_inputs.video_in);
                  alloc_video_buff(&scaler_yuv420_8b_inputs.video_in);               
                  alloc_video_buff(&ycrcb2rgb_inputs.video_in);

                  // Allocate dynamic buffer for output video:
                  alloc_video_buff(&scaler_yuv422_8b_outputs.video_out);
                  alloc_video_buff(&scaler_outputs.video_out);

                  alloc_video_buff(&ycrcb2rgb_outputs.video_out);
                  alloc_yuv8_frame_buff(&yuv8_video_out);
                  // Calculate scale factors so we can write them into reg_in.txt.
                  // Note that this calculation is repeated in the filter kernel, making use of the same 
                  // function CalculateScaleFactor.
                  // It is also repeated in the CreateCoefsMatrix function.
                  y_aperture_h_size = aperture_end_pixel-aperture_start_pixel+1;
                  y_aperture_v_size = aperture_end_line-aperture_start_line+1;

                  hsf = CalculateScaleFactor(aperture_end_pixel-aperture_start_pixel+1, output_h_size);
                  vsf = CalculateScaleFactor(aperture_end_line-aperture_start_line+1, output_v_size);
                  fprintf(cfgFile_fid, "######################################################\n");
                  fprintf(cfgFile_fid, "## Stream %d: (%d frame(s))\n", StreamNumber, frames);
                  fprintf(cfgFile_fid, "##      aperture_start_pixel: %d\n", aperture_start_pixel);
                  fprintf(cfgFile_fid, "##      aperture_end_pixel: %d\n", aperture_end_pixel);
                  fprintf(cfgFile_fid, "##      aperture_start_line: %d\n", aperture_start_line);
                  fprintf(cfgFile_fid, "##      aperture_end_line: %d\n", aperture_end_line);
                  fprintf(cfgFile_fid, "##      output_h_size: %d\n", output_h_size);
                  fprintf(cfgFile_fid, "##      output_v_size: %d\n", output_v_size);
                  fprintf(cfgFile_fid, "##      hsf: %d\n", hsf);
                  fprintf(cfgFile_fid, "##      vsf: %d\n", vsf);
                  fprintf(cfgFile_fid, "##      num_h_phases: %d\n", num_h_phases);
                  fprintf(cfgFile_fid, "##      num_v_phases: %d\n", num_v_phases);
                  fprintf(cfgFile_fid, "##      h_coeff_set: %d\n", h_coeff_set);
                  fprintf(cfgFile_fid, "##      v_coeff_set: %d\n", v_coeff_set);
                  fprintf(cfgFile_fid, "##      start_hpa_y: %d\n", start_hpa_y);
                  fprintf(cfgFile_fid, "##      start_hpa_c: %d\n", start_hpa_c);
                  fprintf(cfgFile_fid, "##      start_vpa_y: %d\n", start_vpa_y);
                  fprintf(cfgFile_fid, "##      start_vpa_c: %d\n", start_vpa_c);
                  fprintf(cfgFile_fid, "##      coef_set_wr_addr: %d\n", coef_set_wr_addr);
                  if (UserCoefsEnabled == 0)
                     fprintf(cfgFile_fid, "##      Using default coefficients.\n");
                  else
                  {
                     fprintf(cfgFile_fid, "##      User coefficients enabled: \n");
                     strcpy(Fname, TestDirName);
                     strcat(Fname, "/");
                     strcat(Fname, user_coef_filename);
                     fprintf(cfgFile_fid, "##      Coefficients file: %s\n\n", Fname); 
                     if ( (user_coefs_fid = fopen(Fname, "r+t" )) == NULL ) 
                     {
                        fprintf(report_fid, "\nError opening file: Could not open %s for reading.\n\n", Fname ); 
                        ErrorCount++; 
                        return(500);
                     }
                     else
                     {
                        scaler_generics.UserCoefsEnabled = 1;
                        fprintf(report_fid, "User-defined coefficients found in %s\n", Fname);
                     }

                     // Generate coefficients matrix from user-specified .coe file
                     // If none specified, set matrix to zero.
                     fprintf(report_fid, "Allocating memory for initial coefficients.\n");
                     alloc_coefs_buff(&scaler_generics.init_coefs, max(num_h_taps, num_v_taps), max_phases);
                     if (scaler_generics.UserCoefsEnabled == 1)
                     {
                        ParseCoeFile(user_coefs_fid, &scaler_generics.init_coefs, text, sizeof text, max(num_h_taps, num_v_taps), max_phases );
                     }
                  }

                  // Start writing the stream parameters (register writes and coefficients) to the output cfg file.
                  fprintf(cfgFile_fid, "PARAM_BEGIN\n");
                  fprintf(cfgFile_fid, "   STIMULI_FILE_NAME = stim%d.txt\n", StreamNumber);
                  fprintf(cfgFile_fid, "   GOLDEN_FILE_NAME  = gold%d.txt\n", StreamNumber);
                  fprintf(cfgFile_fid, "   FRAME_COUNT  = %d\n", frames);
                  if (has_axi4_lite == 1)
                  {
                     fprintf(cfgFile_fid, "   R_CORE_HSF_100 = 0x%08x\n", hsf);
                     fprintf(cfgFile_fid, "   R_CORE_VSF_104 = 0x%08x\n", vsf);
                     fprintf(cfgFile_fid, "   R_CORE_SOURCE_VIDEO_SIZE_108 = 0x%08x\n", (src_v_res<<16) | src_h_res);
                     fprintf(cfgFile_fid, "   R_CORE_H_APERTURE_10c = 0x%08x\n", (aperture_end_pixel<<16) | aperture_start_pixel);
                     fprintf(cfgFile_fid, "   R_CORE_V_APERTURE_110 = 0x%08x\n", (aperture_end_line<<16) | aperture_start_line);
                     fprintf(cfgFile_fid, "   R_CORE_OUTPUT_SIZE_114 = 0x%08x\n", (output_v_size<<16) | output_h_size);
                     fprintf(cfgFile_fid, "   R_CORE_NUM_PHASES_118 = 0x%08x\n", (num_v_phases<<8) | num_h_phases);
                     fprintf(cfgFile_fid, "   R_CORE_ACTIVE_COEFS_11c = 0x%08x\n", (v_coeff_set<<4) | h_coeff_set);
                     fprintf(cfgFile_fid, "   R_CORE_HPA_Y_120 = 0x00000000\n", start_hpa_y);
                     fprintf(cfgFile_fid, "   R_CORE_HPA_C_124 = 0x00000000\n", start_hpa_c);
                     fprintf(cfgFile_fid, "   R_CORE_VPA_Y_128 = 0x00000000\n", start_vpa_y);
                     fprintf(cfgFile_fid, "   R_CORE_VPA_C_12c = 0x00000000\n", start_vpa_c);
                     fprintf(cfgFile_fid, "   R_CORE_COEF_SET_WR_ADDR_130 = 0x00000000\n", coef_set_wr_addr);
                     fprintf(cfgFile_fid, "   R_CORE_COEF_SET_BANK_RD_ADDR_138 = 0x00000000\n");
                     fprintf(cfgFile_fid, "   R_CORE_COEF_MEM_RD_ADDR_13c = 0x00000000\n");
                  }
                  ////////////////////////////////////////////////////////////////////////
                  // Predetermine the coefficients that will be used to scale this stream.
                  //   Populate the SingleFrameCoefs element in the scaler_yuv422_8b_inputs structure.
                  ////////////////////////////////////////////////////////////////////////

                  
                  alloc_coefs_buff(&scaler_inputs.SingleFrameCoefs, max(num_h_taps, num_v_taps), max_phases);
                  alloc_coefs_buff(&scaler_yuv422_8b_inputs.SingleFrameCoefs, max(num_h_taps, num_v_taps), max_phases);
                  alloc_coefs_buff(&scaler_yuv420_8b_inputs.SingleFrameCoefs, max(num_h_taps, num_v_taps), max_phases);
                  
                  Y_coef_matrix_H_for_output =(int *)calloc(num_h_taps*num_h_phases, sizeof(int));
                  Y_coef_matrix_V_for_output =(int *)calloc(num_v_taps*num_v_phases, sizeof(int));
                  UV_coef_matrix_H_for_output =(int *)calloc(num_h_taps*num_h_phases, sizeof(int));
                  UV_coef_matrix_V_for_output =(int *)calloc(num_v_taps*num_v_phases, sizeof(int));

                  CreateCoefsMatrix(scaler_generics, scaler_inputs, &scaler_outputs, ForceUnityCoefs);
                  CreateCoefsMatrix(scaler_generics, scaler_yuv422_8b_inputs, &scaler_yuv422_8b_outputs, ForceUnityCoefs);
 
                 // Assign H coefficients to be written to cfg file for this stream.
                  for (i=0;i<num_h_phases;i++)
                  {
                     for (j=0;j<num_h_taps;j++)
                     {  
                        Y_coef_matrix_H_for_output[(i*num_h_taps)+j]    = scaler_inputs.SingleFrameCoefs.coefficients[0][i][j];
                        UV_coef_matrix_H_for_output[(i*num_h_taps)+j]   = scaler_inputs.SingleFrameCoefs.coefficients[1][i][j];

                     }
                  }
                  // Assign V coefficients to be used for this stream.
                  for (i=0;i<num_v_phases;i++)
                  {
                     for (j=0;j<num_v_taps;j++)
                     {
                        Y_coef_matrix_V_for_output[(i*num_v_taps)+j]    = scaler_inputs.SingleFrameCoefs.coefficients[2][i][j];
                        UV_coef_matrix_V_for_output[(i*num_v_taps)+j]   = scaler_inputs.SingleFrameCoefs.coefficients[3][i][j];
                     }
                  }

                  // Write coefficients to the output .cfg file.
                  WriteCoefsFile(
                           cfgFile_fid, miffid, GenerateCFGFile,
                           Y_coef_matrix_H_for_output, UV_coef_matrix_H_for_output, Y_coef_matrix_V_for_output, UV_coef_matrix_V_for_output, 
                           num_h_taps, num_v_taps, 
                           max_phases, num_h_phases, num_v_phases,
                           Separate_YC_Coefs, Separate_HV_Coefs, scaler_inputs.video_in.mode,
                           has_axi4_lite);
                  if (has_axi4_lite == 1)
                     fprintf(cfgFile_fid, "   R_CONTROL_00 = 0x00000003\n");
                  fprintf(cfgFile_fid, "PARAM_END\n");
                  fprintf(cfgFile_fid, "## End of Stream %d\n", StreamNumber);
                  fprintf(cfgFile_fid, "######################################################\n\n");

                  if (ErrorCount > 0)
                  {
                     fprintf(report_fid, "Number of errors %d\n", ErrorCount);
                     return(201);
                  }
                  AppendCoeFileMatrix(StreamNumber-1, scaler_generics, scaler_inputs);

                  // Now write the .coe file.
                  if (CreateCoeFile == 1)
                     WriteCoeFile(output_coe_fid, scaler_generics, scaler_inputs, StreamNumber);
                  // Here we go: invoke the scaler model....
                  if (ParseYUVFile == 1) 
                  {
                     ret_val = ExecuteScalerModel(  input_fid, 
                                          output_fid, 
                                          frames, 
                                          EnableYUVOutputGeneration, 
                                          EnableRamp, 
                                          EnableRandom);
                     fprintf(report_fid, "ExecuteScalerModel return value: %d\n", ret_val);
                     if (ret_val != 0) return (ret_val);
                  }
                  // Now that all frames for this stream have been generated, free dynamic video and coefficient buffers :
                  free_yuv_frame_buff((struct yuv_video_struct*) &yuv8_video_in);
                  free_yuv_frame_buff((struct yuv_video_struct*) &ycrcb444_video_in);
                  free_yuv_frame_buff((struct yuv_video_struct*) &ycrcb420_video_in);
                  free_video_buff(&scaler_yuv422_8b_inputs.video_in);
                  free_video_buff(&scaler_yuv420_8b_inputs.video_in);
                  free_video_buff(&ycrcb2rgb_inputs.video_in);
                  free_video_buff(&ycrcb2rgb_outputs.video_out);
                  free_yuv_frame_buff((struct yuv_video_struct*) &yuv8_video_out);

                  if (StreamNumber > MAX_TEST_CASES)
                  {
                     fprintf (report_fid, "Error: Maximum number of streams (%d) exceeded in test %s . \n\n", MAX_TEST_CASES, cfg_testname);
                     return(300);
                  }

                  if (ParseYUVFile == 1) 
                  {
                     fprintf (report_fid, "Closing Input YUV file for this stream. It may be re-opened if there is another stream.\n");
                     fclose(input_fid); 
                  }
               }
            }
            else
            {
               printf ("Unknown command found in config file on line %d: \n\n   %s\n\n", line_num, line);
               if (RepoDirFound == 1)
                  fprintf (report_fid, "Unknown command found in config file on line %d: \n\n   %s\n\n", line_num, line);
               ErrorCount++;
               return(600);
            }
         }

         line_num++;
      }
   }

   fclose(report_fid);
   if (EnableYUVOutputGeneration == 1)
      fclose(output_fid);
   if (CreateCoeFile == 1)
      fclose(output_coe_fid);

   printf("Done\n");
   return(ret_val);
}


int yuv_processing(char* config_filename, char* testname, char* YUVFile, int hsize, int vsize)

{
   FILE*       config_fid     = NULL; 

   int   ret_val = 2000;
   int   frames, i;
   int   OWIDTH = 8;

   char  text[256] = "";

  // Initialize generics and inputs structure with defaults:
  if ((ret_val = xilinx_ip_v_ycrcb2rgb_v4_0_get_default_generics(&ycrcb2rgb_generics))>0) return(ret_val);
  if ((ret_val = xilinx_ip_v_ycrcb2rgb_v4_0_get_default_inputs(&ycrcb2rgb_generics, &ycrcb2rgb_inputs))>0) return(ret_val); 
  
  ycrcb2rgb_generics.OWIDTH = OWIDTH;
  ycrcb2rgb_generics.CWIDTH = 8;
  ycrcb2rgb_generics.ACOEF  = 0.4;
  ycrcb2rgb_generics.RGBMAX = (1<<(OWIDTH-4))*15;
  ycrcb2rgb_generics.RGBMIN = (1<<(OWIDTH-4));
  ycrcb2rgb_generics.YOFFSET= 15;
  ycrcb2rgb_generics.COFFSET= 120;

   if ( (config_fid = fopen(config_filename, "r+t" )) == NULL ) 
   {
      printf( "\nError opening file: Could not open config file %s \n\n", config_filename ); 

      ErrorCount++;
      return(10); 
   }
   else
   {
      printf ("Opening %s\n", config_filename);
      CfgFileFound = 1;
   }


   ////////////////////////////////////////////////////////////
   // Initialize input parameters:
   yuv8_video_in.y                                 =  NULL;
   yuv8_video_in.u                                 =  NULL;
   yuv8_video_in.v                                 =  NULL;
   scaler_yuv422_8b_inputs.video_in.data[0]              =  NULL;
   scaler_yuv422_8b_inputs.video_in.data[1]              =  NULL;
   scaler_yuv422_8b_inputs.video_in.data[2]              =  NULL;
   scaler_yuv420_8b_inputs.video_in.data[0]              =  NULL;
   scaler_yuv420_8b_inputs.video_in.data[1]              =  NULL;
   scaler_yuv420_8b_inputs.video_in.data[2]              =  NULL;
   ////////////////////////////////////////////////////////////
   // Initialize output parameters:
   scaler_yuv422_8b_outputs.video_out.data[0]      =  NULL;
   scaler_yuv422_8b_outputs.video_out.data[1]      =  NULL;
   scaler_yuv422_8b_outputs.video_out.data[2]      =  NULL;
   yuv8_video_out.y                                =  NULL;
   yuv8_video_out.u                                =  NULL;
   yuv8_video_out.v                                =  NULL;


   ret_val=read_config_file(config_fid, text, sizeof text, testname, YUVFile, hsize, vsize);  

   return (ret_val);
}

int main( int argc, char* argv[] )
{  
   int ret_val, i;
   unsigned char inchar0;
   char  config_filename[2048] = { 0 }; 
   char  YUVFile[2048] = { 0 }; 
   char  testname[2048] = { 0 }; 
   int hsize = 0;
   int vsize = 0;
   char * cwd;
   int   UserCFG = 0;
   int   UserTest = 0;
   int   UserYUV = 0;
   int   UserHSize = 0;
   int   UserVSize = 0;

   if (argc<7) 
      exit(print_help()); 
   else
   {

      for (i=1;i<argc;i++)
      {
         // -c switch allows the user to point to a .cfg file eg scaler.cfg.
         if ((strcmp(argv[i], "-c")) == 0)
         {
            strcpy(config_filename, argv[i+1]);
            UserCFG = 1;
         }

         // -t switch allows the user to point to particular test in the .cfg file.
         if ((strcmp(argv[i], "-t")) == 0)
         {
            strcpy(testname, argv[i+1]);
            UserTest = 1;
         }

         // -y switch allows the user to point to an input .yuv file.
         if ((strcmp(argv[i], "-y")) == 0)
         {
            strcpy(YUVFile, argv[i+1]);
            UserYUV = 1;
         }

         // -h switch is the H resolution of input video source.
         if ((strcmp(argv[i], "-h")) == 0)
         {
           hsize =  atoi( argv[i+1]);
            UserHSize = 1;
            
         }

         // -v switch is the V resolution of input video source.
         if ((strcmp(argv[i], "-v")) == 0)
         {
            vsize =  atoi( argv[i+1]); 
            UserVSize = 1;
         }
      }
   }
   if ((UserCFG == 0) || (UserTest == 0) || (UserYUV == 0) || (UserHSize == 0) || (UserVSize == 0))
      exit(print_help()); 

   ret_val = yuv_processing(config_filename, testname, YUVFile, hsize, vsize);
   printf("\n");
   

   fcloseall();
   if (ErrorCount == 0)
      printf("\nConfig file parsed successfully!\n\n");
   else
      printf("\nErrors found.\n\n");
   if (WarningCount != 0)
      printf("\nWarnings found. \n\n");

   if (RepoDirFound ==1)
   {
      printf("Please refer to %s for summary.\n", ReportFname);
   }

   return(ret_val);
}
